from pydantic_settings import BaseSettings
from typing import List


class Settings(BaseSettings):
    # App
    APP_NAME: str = "Postlane"
    DEBUG: bool = False
    SECRET_KEY: str = "change-me-in-production-use-openssl-rand-hex-32"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24  # 24 hours

    # Database
    DATABASE_URL: str = "postgresql+asyncpg://postlane:postlane@localhost:5432/postlane"

    # Redis
    REDIS_URL: str = "redis://localhost:6379"

    # CORS
    ALLOWED_ORIGINS: List[str] = ["http://localhost:3000", "http://localhost:3001"]

    # Twitter/X OAuth
    TWITTER_CLIENT_ID: str = ""
    TWITTER_CLIENT_SECRET: str = ""
    TWITTER_REDIRECT_URI: str = "http://localhost:8000/api/auth/twitter/callback"

    # LinkedIn OAuth
    LINKEDIN_CLIENT_ID: str = ""
    LINKEDIN_CLIENT_SECRET: str = ""
    LINKEDIN_REDIRECT_URI: str = "http://localhost:8000/api/auth/linkedin/callback"

    # Mastodon OAuth
    MASTODON_INSTANCE: str = "https://mastodon.social"
    MASTODON_CLIENT_ID: str = ""
    MASTODON_CLIENT_SECRET: str = ""
    MASTODON_REDIRECT_URI: str = "http://localhost:8000/api/auth/mastodon/callback"

    # Queue
    MAX_CONCURRENT_WORKERS: int = 10
    MAX_RETRIES: int = 3
    RETRY_BACKOFF_SECONDS: int = 60

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
