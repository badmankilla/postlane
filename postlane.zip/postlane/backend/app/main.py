from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from app.api import posts, analytics, auth, connections, queue
from app.core.config import settings
from app.core.database import init_db
from app.core.redis import init_redis


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    await init_redis()
    yield


app = FastAPI(
    title="Postlane API",
    description="Social Media Scheduler for Indie Hackers",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/api/auth", tags=["auth"])
app.include_router(posts.router, prefix="/api/posts", tags=["posts"])
app.include_router(queue.router, prefix="/api/queue", tags=["queue"])
app.include_router(analytics.router, prefix="/api/analytics", tags=["analytics"])
app.include_router(connections.router, prefix="/api/connections", tags=["connections"])


@app.get("/health")
async def health():
    return {"status": "ok", "service": "postlane-api"}
