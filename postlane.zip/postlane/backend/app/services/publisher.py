"""
Publisher — calls each platform's API to post content.
Handles token refresh, rate limits, and error mapping.
"""
import logging
import httpx
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.models.user import Post, SocialConnection, Platform
from app.core.config import settings

logger = logging.getLogger(__name__)


async def publish_post(post: Post, db: AsyncSession) -> str:
    """Publish a post to its platform. Returns the platform's post ID."""
    result = await db.execute(
        select(SocialConnection).where(
            SocialConnection.user_id == post.user_id,
            SocialConnection.platform == post.platform,
            SocialConnection.is_active == True,
        )
    )
    connection = result.scalar_one_or_none()
    if not connection:
        raise ValueError(f"No active {post.platform} connection for user {post.user_id}")

    publishers = {
        Platform.TWITTER: _publish_twitter,
        Platform.LINKEDIN: _publish_linkedin,
        Platform.MASTODON: _publish_mastodon,
    }

    publisher = publishers.get(post.platform)
    if not publisher:
        raise ValueError(f"Unsupported platform: {post.platform}")

    return await publisher(post.content, connection)


async def _publish_twitter(content: str, conn: SocialConnection) -> str:
    """POST to Twitter v2 /tweets endpoint."""
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            "https://api.twitter.com/2/tweets",
            json={"text": content[:280]},
            headers={
                "Authorization": f"Bearer {conn.access_token}",
                "Content-Type": "application/json",
            },
        )
        if resp.status_code == 429:
            raise RuntimeError("Twitter rate limit exceeded — will retry")
        resp.raise_for_status()
        data = resp.json()
        return data["data"]["id"]


async def _publish_linkedin(content: str, conn: SocialConnection) -> str:
    """POST to LinkedIn v2 /ugcPosts endpoint."""
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            "https://api.linkedin.com/v2/ugcPosts",
            json={
                "author": f"urn:li:person:{conn.platform_user_id}",
                "lifecycleState": "PUBLISHED",
                "specificContent": {
                    "com.linkedin.ugc.ShareContent": {
                        "shareCommentary": {"text": content[:3000]},
                        "shareMediaCategory": "NONE",
                    }
                },
                "visibility": {"com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"},
            },
            headers={
                "Authorization": f"Bearer {conn.access_token}",
                "Content-Type": "application/json",
                "X-Restli-Protocol-Version": "2.0.0",
            },
        )
        if resp.status_code == 429:
            raise RuntimeError("LinkedIn rate limit exceeded — will retry")
        resp.raise_for_status()
        return resp.headers.get("x-restli-id", "unknown")


async def _publish_mastodon(content: str, conn: SocialConnection) -> str:
    """POST to Mastodon /api/v1/statuses endpoint."""
    instance = settings.MASTODON_INSTANCE
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            f"{instance}/api/v1/statuses",
            json={"status": content[:500], "visibility": "public"},
            headers={
                "Authorization": f"Bearer {conn.access_token}",
                "Content-Type": "application/json",
            },
        )
        if resp.status_code == 429:
            raise RuntimeError("Mastodon rate limit exceeded — will retry")
        resp.raise_for_status()
        data = resp.json()
        return data["id"]
