"""
Queue service — Redis-backed job scheduler using sorted sets.
Mimics BullMQ's pattern: jobs live in sorted sets keyed by score = run_at timestamp.
Workers poll for due jobs, lock them, execute, then ack or retry.
"""
import json
import uuid
import asyncio
import logging
from datetime import datetime, timezone
from typing import Optional
import redis.asyncio as aioredis
from app.core.config import settings

logger = logging.getLogger(__name__)

QUEUE_WAITING  = "postlane:queue:waiting"   # ZSET  score=scheduled_unix
QUEUE_ACTIVE   = "postlane:queue:active"    # ZSET  score=started_unix
QUEUE_DONE     = "postlane:queue:done"      # ZSET  score=completed_unix
QUEUE_FAILED   = "postlane:queue:failed"    # ZSET  score=failed_unix
JOB_DATA_KEY   = "postlane:job:{job_id}"   # HASH  job metadata
LOCK_KEY       = "postlane:lock:{job_id}"  # STRING  worker lock (TTL 120s)
STATS_KEY      = "postlane:stats"          # HASH  counters


class QueueService:
    def __init__(self, redis: aioredis.Redis):
        self.redis = redis

    # ── Enqueue ───────────────────────────────────────────
    async def enqueue(
        self,
        post_id: int,
        platform: str,
        scheduled_at: datetime,
        content: str,
        user_id: int,
    ) -> str:
        job_id = f"post_{post_id}_{platform}_{uuid.uuid4().hex[:8]}"
        run_at = scheduled_at.timestamp()

        job_data = {
            "job_id": job_id,
            "post_id": str(post_id),
            "platform": platform,
            "user_id": str(user_id),
            "content": content[:280],  # truncate for safety
            "scheduled_at": scheduled_at.isoformat(),
            "attempts": "0",
            "max_attempts": str(settings.MAX_RETRIES),
            "status": "waiting",
            "created_at": datetime.now(timezone.utc).isoformat(),
        }

        pipe = self.redis.pipeline()
        pipe.hset(JOB_DATA_KEY.format(job_id=job_id), mapping=job_data)
        pipe.expire(JOB_DATA_KEY.format(job_id=job_id), 60 * 60 * 24 * 30)  # 30-day TTL
        pipe.zadd(QUEUE_WAITING, {job_id: run_at})
        pipe.hincrby(STATS_KEY, "total_queued", 1)
        await pipe.execute()

        logger.info(f"Enqueued job {job_id} for {platform} at {scheduled_at}")
        return job_id

    # ── Dequeue due jobs (called by worker) ───────────────
    async def dequeue_due(self) -> Optional[dict]:
        now = datetime.now(timezone.utc).timestamp()
        # Atomically pop the earliest job that's due
        jobs = await self.redis.zrangebyscore(QUEUE_WAITING, 0, now, start=0, num=1)
        if not jobs:
            return None

        job_id = jobs[0]
        lock_key = LOCK_KEY.format(job_id=job_id)

        # Try to acquire lock (prevents duplicate processing in concurrent workers)
        acquired = await self.redis.set(lock_key, "1", nx=True, ex=120)
        if not acquired:
            return None  # Another worker grabbed it

        # Move to active
        pipe = self.redis.pipeline()
        pipe.zrem(QUEUE_WAITING, job_id)
        pipe.zadd(QUEUE_ACTIVE, {job_id: now})
        pipe.hset(JOB_DATA_KEY.format(job_id=job_id), mapping={
            "status": "active",
            "started_at": datetime.now(timezone.utc).isoformat(),
        })
        await pipe.execute()

        data = await self.redis.hgetall(JOB_DATA_KEY.format(job_id=job_id))
        return data if data else None

    # ── Acknowledge success ────────────────────────────────
    async def ack(self, job_id: str):
        now = datetime.now(timezone.utc).timestamp()
        pipe = self.redis.pipeline()
        pipe.zrem(QUEUE_ACTIVE, job_id)
        pipe.zadd(QUEUE_DONE, {job_id: now})
        pipe.delete(LOCK_KEY.format(job_id=job_id))
        pipe.hset(JOB_DATA_KEY.format(job_id=job_id), mapping={
            "status": "done",
            "completed_at": datetime.now(timezone.utc).isoformat(),
        })
        pipe.hincrby(STATS_KEY, "total_sent", 1)
        await pipe.execute()

    # ── Nack / retry ──────────────────────────────────────
    async def nack(self, job_id: str, error: str, retry: bool = True):
        data = await self.redis.hgetall(JOB_DATA_KEY.format(job_id=job_id))
        attempts = int(data.get("attempts", 0)) + 1
        max_attempts = int(data.get("max_attempts", settings.MAX_RETRIES))

        pipe = self.redis.pipeline()
        pipe.zrem(QUEUE_ACTIVE, job_id)
        pipe.delete(LOCK_KEY.format(job_id=job_id))
        pipe.hset(JOB_DATA_KEY.format(job_id=job_id), mapping={
            "attempts": str(attempts),
            "last_error": error[:500],
        })

        if retry and attempts < max_attempts:
            # Exponential backoff: 60s, 120s, 240s …
            delay = settings.RETRY_BACKOFF_SECONDS * (2 ** (attempts - 1))
            retry_at = datetime.now(timezone.utc).timestamp() + delay
            pipe.zadd(QUEUE_WAITING, {job_id: retry_at})
            pipe.hset(JOB_DATA_KEY.format(job_id=job_id), "status", "retrying")
            logger.warning(f"Retrying job {job_id} in {delay}s (attempt {attempts}/{max_attempts})")
        else:
            now = datetime.now(timezone.utc).timestamp()
            pipe.zadd(QUEUE_FAILED, {job_id: now})
            pipe.hset(JOB_DATA_KEY.format(job_id=job_id), "status", "failed")
            pipe.hincrby(STATS_KEY, "total_failed", 1)
            logger.error(f"Job {job_id} permanently failed after {attempts} attempts: {error}")

        await pipe.execute()

    # ── Stats ─────────────────────────────────────────────
    async def get_stats(self) -> dict:
        pipe = self.redis.pipeline()
        pipe.zcard(QUEUE_WAITING)
        pipe.zcard(QUEUE_ACTIVE)
        pipe.zcard(QUEUE_DONE)
        pipe.zcard(QUEUE_FAILED)
        pipe.hgetall(STATS_KEY)
        results = await pipe.execute()

        waiting, active, done, failed, counters = results
        total_sent = int(counters.get("total_sent", 0))
        total_queued = int(counters.get("total_queued", 0))
        on_time = round((total_sent / max(total_queued, 1)) * 100, 1) if total_queued else 100.0

        # Next due job
        next_jobs = await self.redis.zrange(QUEUE_WAITING, 0, 0, withscores=True)
        next_in = None
        if next_jobs:
            next_ts = next_jobs[0][1]
            delta = next_ts - datetime.now(timezone.utc).timestamp()
            next_in = max(0, int(delta))

        return {
            "queued": waiting,
            "processing": active,
            "completed": done,
            "failed": failed,
            "on_time_rate": on_time,
            "next_delivery_in_seconds": next_in,
            "worker_count": settings.MAX_CONCURRENT_WORKERS,
        }

    async def get_job(self, job_id: str) -> Optional[dict]:
        return await self.redis.hgetall(JOB_DATA_KEY.format(job_id=job_id)) or None

    async def cancel_job(self, job_id: str) -> bool:
        removed = await self.redis.zrem(QUEUE_WAITING, job_id)
        if removed:
            await self.redis.hset(JOB_DATA_KEY.format(job_id=job_id), "status", "cancelled")
        return bool(removed)
