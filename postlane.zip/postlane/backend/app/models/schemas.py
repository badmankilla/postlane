from pydantic import BaseModel, EmailStr, Field, field_validator
from datetime import datetime
from typing import Optional, List
from app.models.user import Platform, PostStatus


# ── Auth ──────────────────────────────────────────────────
class UserRegister(BaseModel):
    email: EmailStr
    username: str = Field(min_length=3, max_length=50)
    password: str = Field(min_length=8)
    full_name: Optional[str] = None


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserOut(BaseModel):
    id: int
    email: str
    username: str
    full_name: Optional[str]
    avatar_url: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True


# ── Posts ─────────────────────────────────────────────────
class PostCreate(BaseModel):
    content: str = Field(min_length=1, max_length=500)
    platforms: List[Platform] = Field(min_length=1)
    scheduled_at: datetime
    media_urls: Optional[List[str]] = []

    @field_validator("content")
    @classmethod
    def content_not_empty(cls, v):
        if not v.strip():
            raise ValueError("Content cannot be empty")
        return v.strip()


class PostUpdate(BaseModel):
    content: Optional[str] = Field(None, min_length=1, max_length=500)
    scheduled_at: Optional[datetime] = None
    status: Optional[PostStatus] = None


class PostAnalyticsOut(BaseModel):
    impressions: int
    engagements: int
    likes: int
    reposts: int
    replies: int
    link_clicks: int
    engagement_rate: float
    fetched_at: datetime

    class Config:
        from_attributes = True


class PostOut(BaseModel):
    id: int
    content: str
    platform: Platform
    status: PostStatus
    scheduled_at: datetime
    sent_at: Optional[datetime]
    platform_post_id: Optional[str]
    error_message: Optional[str]
    retry_count: int
    job_id: Optional[str]
    media_urls: List[str]
    created_at: datetime
    analytics: Optional[List[PostAnalyticsOut]] = []

    class Config:
        from_attributes = True


# ── Queue ─────────────────────────────────────────────────
class QueueStats(BaseModel):
    queued: int
    processing: int
    completed: int
    failed: int
    on_time_rate: float
    next_delivery_in_seconds: Optional[int]
    worker_count: int


class JobInfo(BaseModel):
    job_id: str
    post_id: int
    platform: Platform
    scheduled_at: datetime
    status: str
    attempts: int
    delay_seconds: int


# ── Analytics ─────────────────────────────────────────────
class AnalyticsSummary(BaseModel):
    total_impressions: int
    total_engagements: int
    total_posts: int
    avg_engagement_rate: float
    total_link_clicks: int
    follower_gain: int
    period_days: int


class DailyStats(BaseModel):
    date: str
    impressions: int
    engagements: int
    posts_sent: int


class TopPost(BaseModel):
    id: int
    content: str
    platform: Platform
    impressions: int
    engagements: int
    engagement_rate: float
    sent_at: Optional[datetime]


# ── Connections ───────────────────────────────────────────
class ConnectionOut(BaseModel):
    id: int
    platform: Platform
    platform_username: Optional[str]
    is_active: bool
    rate_limit_remaining: Optional[int]
    rate_limit_reset_at: Optional[datetime]
    created_at: datetime

    class Config:
        from_attributes = True


class OAuthInitResponse(BaseModel):
    auth_url: str
    state: str
