"""
Worker — polls Redis every 5 s for due jobs and dispatches to platform publishers.
Run with: python -m app.workers.worker
Supports MAX_CONCURRENT_WORKERS simultaneous tasks via asyncio semaphore.
"""
import asyncio
import logging
import signal
from datetime import datetime, timezone

from app.core.config import settings
from app.core.redis import init_redis, get_redis
from app.core.database import init_db, AsyncSessionLocal
from app.services.queue_service import QueueService
from app.services.publisher import publish_post
from app.models.user import Post, PostStatus

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

POLL_INTERVAL = 5  # seconds
shutdown_event = asyncio.Event()


async def process_job(job: dict, queue_svc: QueueService):
    job_id = job["job_id"]
    post_id = int(job["post_id"])
    platform = job["platform"]

    logger.info(f"Processing job {job_id} | post={post_id} platform={platform}")

    try:
        async with AsyncSessionLocal() as db:
            post = await db.get(Post, post_id)
            if not post:
                await queue_svc.nack(job_id, "Post not found", retry=False)
                return

            post.status = PostStatus.PROCESSING
            await db.commit()

            platform_post_id = await publish_post(post, db)

            post.status = PostStatus.SENT
            post.sent_at = datetime.now(timezone.utc)
            post.platform_post_id = platform_post_id
            await db.commit()

        await queue_svc.ack(job_id)
        logger.info(f"✓ Job {job_id} delivered → {platform}:{platform_post_id}")

    except Exception as e:
        logger.error(f"✗ Job {job_id} failed: {e}")
        async with AsyncSessionLocal() as db:
            post = await db.get(Post, post_id)
            if post:
                attempts = int(job.get("attempts", 0)) + 1
                if attempts >= int(job.get("max_attempts", settings.MAX_RETRIES)):
                    post.status = PostStatus.FAILED
                    post.error_message = str(e)
                else:
                    post.status = PostStatus.QUEUED
                await db.commit()

        await queue_svc.nack(job_id, str(e), retry=True)


async def run_worker():
    await init_db()
    await init_redis()
    redis = await get_redis()
    queue_svc = QueueService(redis)
    semaphore = asyncio.Semaphore(settings.MAX_CONCURRENT_WORKERS)

    logger.info(f"Worker started | max_concurrent={settings.MAX_CONCURRENT_WORKERS} poll={POLL_INTERVAL}s")

    tasks: set[asyncio.Task] = set()

    while not shutdown_event.is_set():
        try:
            job = await queue_svc.dequeue_due()
            if job:
                async def bounded(j=job):
                    async with semaphore:
                        await process_job(j, queue_svc)

                task = asyncio.create_task(bounded())
                tasks.add(task)
                task.add_done_callback(tasks.discard)
            else:
                await asyncio.sleep(POLL_INTERVAL)
        except Exception as e:
            logger.error(f"Worker loop error: {e}")
            await asyncio.sleep(POLL_INTERVAL)

    # Drain remaining tasks on shutdown
    if tasks:
        logger.info(f"Draining {len(tasks)} in-flight tasks…")
        await asyncio.gather(*tasks, return_exceptions=True)
    logger.info("Worker shut down cleanly")


def handle_signal():
    logger.info("Shutdown signal received")
    shutdown_event.set()


if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, handle_signal)
    loop.run_until_complete(run_worker())
