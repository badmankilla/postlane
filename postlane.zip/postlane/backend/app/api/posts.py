from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from datetime import datetime, timezone
from typing import List, Optional

from app.core.database import get_db
from app.core.security import get_current_user
from app.core.redis import get_redis
from app.models.user import User, Post, PostStatus, Platform
from app.models.schemas import PostCreate, PostOut, PostUpdate
from app.services.queue_service import QueueService

router = APIRouter()


@router.post("/", response_model=List[PostOut], status_code=201)
async def schedule_posts(
    data: PostCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    redis=Depends(get_redis),
):
    """Schedule a post across one or more platforms."""
    if data.scheduled_at <= datetime.now(timezone.utc):
        raise HTTPException(status_code=400, detail="Scheduled time must be in the future")

    queue_svc = QueueService(redis)
    created_posts = []

    for platform in data.platforms:
        post = Post(
            user_id=current_user.id,
            content=data.content,
            platform=platform,
            status=PostStatus.QUEUED,
            scheduled_at=data.scheduled_at,
            media_urls=data.media_urls or [],
        )
        db.add(post)
        await db.flush()  # get post.id

        job_id = await queue_svc.enqueue(
            post_id=post.id,
            platform=platform.value,
            scheduled_at=data.scheduled_at,
            content=data.content,
            user_id=current_user.id,
        )
        post.job_id = job_id
        created_posts.append(post)

    await db.flush()
    for p in created_posts:
        await db.refresh(p)

    return created_posts


@router.get("/", response_model=List[PostOut])
async def list_posts(
    status: Optional[PostStatus] = None,
    platform: Optional[Platform] = None,
    limit: int = Query(50, le=200),
    offset: int = 0,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    q = select(Post).where(Post.user_id == current_user.id)
    if status:
        q = q.where(Post.status == status)
    if platform:
        q = q.where(Post.platform == platform)
    q = q.order_by(desc(Post.scheduled_at)).limit(limit).offset(offset)
    result = await db.execute(q)
    return result.scalars().all()


@router.get("/{post_id}", response_model=PostOut)
async def get_post(
    post_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    post = await db.get(Post, post_id)
    if not post or post.user_id != current_user.id:
        raise HTTPException(status_code=404, detail="Post not found")
    return post


@router.patch("/{post_id}", response_model=PostOut)
async def update_post(
    post_id: int,
    data: PostUpdate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    redis=Depends(get_redis),
):
    post = await db.get(Post, post_id)
    if not post or post.user_id != current_user.id:
        raise HTTPException(status_code=404, detail="Post not found")
    if post.status not in (PostStatus.DRAFT, PostStatus.QUEUED):
        raise HTTPException(status_code=400, detail="Cannot edit a post that is already processing or sent")

    if data.content is not None:
        post.content = data.content
    if data.scheduled_at is not None:
        # Re-enqueue with new time
        if post.job_id:
            queue_svc = QueueService(redis)
            await queue_svc.cancel_job(post.job_id)
            job_id = await queue_svc.enqueue(
                post_id=post.id,
                platform=post.platform.value,
                scheduled_at=data.scheduled_at,
                content=post.content,
                user_id=current_user.id,
            )
            post.job_id = job_id
        post.scheduled_at = data.scheduled_at

    await db.flush()
    await db.refresh(post)
    return post


@router.delete("/{post_id}", status_code=204)
async def delete_post(
    post_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    redis=Depends(get_redis),
):
    post = await db.get(Post, post_id)
    if not post or post.user_id != current_user.id:
        raise HTTPException(status_code=404, detail="Post not found")
    if post.status == PostStatus.PROCESSING:
        raise HTTPException(status_code=400, detail="Cannot delete a post currently being processed")

    if post.job_id:
        queue_svc = QueueService(redis)
        await queue_svc.cancel_job(post.job_id)

    await db.delete(post)
