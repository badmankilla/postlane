from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List
import secrets
import httpx

from app.core.database import get_db
from app.core.security import get_current_user
from app.core.redis import get_redis
from app.core.config import settings
from app.models.user import User, SocialConnection, Platform
from app.models.schemas import ConnectionOut, OAuthInitResponse

router = APIRouter()

STATE_TTL = 600  # 10 minutes


# ── List connections ──────────────────────────────────────
@router.get("/", response_model=List[ConnectionOut])
async def list_connections(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(SocialConnection).where(SocialConnection.user_id == current_user.id)
    )
    return result.scalars().all()


@router.delete("/{platform}", status_code=204)
async def disconnect(
    platform: Platform,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(SocialConnection).where(
            SocialConnection.user_id == current_user.id,
            SocialConnection.platform == platform,
        )
    )
    conn = result.scalar_one_or_none()
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    await db.delete(conn)


# ── Twitter OAuth 2.0 PKCE ────────────────────────────────
@router.get("/twitter/init", response_model=OAuthInitResponse)
async def twitter_init(
    current_user: User = Depends(get_current_user),
    redis=Depends(get_redis),
):
    state = secrets.token_urlsafe(32)
    await redis.setex(f"oauth:state:{state}", STATE_TTL, str(current_user.id))

    auth_url = (
        f"https://twitter.com/i/oauth2/authorize"
        f"?response_type=code"
        f"&client_id={settings.TWITTER_CLIENT_ID}"
        f"&redirect_uri={settings.TWITTER_REDIRECT_URI}"
        f"&scope=tweet.read%20tweet.write%20users.read%20offline.access"
        f"&state={state}"
        f"&code_challenge=challenge"
        f"&code_challenge_method=plain"
    )
    return {"auth_url": auth_url, "state": state}


@router.get("/twitter/callback")
async def twitter_callback(
    code: str,
    state: str,
    db: AsyncSession = Depends(get_db),
    redis=Depends(get_redis),
):
    user_id = await redis.get(f"oauth:state:{state}")
    if not user_id:
        raise HTTPException(status_code=400, detail="Invalid or expired OAuth state")
    await redis.delete(f"oauth:state:{state}")

    async with httpx.AsyncClient() as client:
        token_resp = await client.post(
            "https://api.twitter.com/2/oauth2/token",
            data={
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": settings.TWITTER_REDIRECT_URI,
                "client_id": settings.TWITTER_CLIENT_ID,
                "code_verifier": "challenge",
            },
            auth=(settings.TWITTER_CLIENT_ID, settings.TWITTER_CLIENT_SECRET),
        )
        token_resp.raise_for_status()
        tokens = token_resp.json()

        me_resp = await client.get(
            "https://api.twitter.com/2/users/me",
            headers={"Authorization": f"Bearer {tokens['access_token']}"},
        )
        me_resp.raise_for_status()
        me = me_resp.json()["data"]

    await _upsert_connection(
        db=db,
        user_id=int(user_id),
        platform=Platform.TWITTER,
        platform_user_id=me["id"],
        platform_username=me["username"],
        access_token=tokens["access_token"],
        refresh_token=tokens.get("refresh_token"),
    )
    return RedirectResponse(url="http://localhost:3000/connections?connected=twitter")


# ── LinkedIn OAuth 2.0 ────────────────────────────────────
@router.get("/linkedin/init", response_model=OAuthInitResponse)
async def linkedin_init(
    current_user: User = Depends(get_current_user),
    redis=Depends(get_redis),
):
    state = secrets.token_urlsafe(32)
    await redis.setex(f"oauth:state:{state}", STATE_TTL, str(current_user.id))

    auth_url = (
        f"https://www.linkedin.com/oauth/v2/authorization"
        f"?response_type=code"
        f"&client_id={settings.LINKEDIN_CLIENT_ID}"
        f"&redirect_uri={settings.LINKEDIN_REDIRECT_URI}"
        f"&scope=r_liteprofile%20w_member_social"
        f"&state={state}"
    )
    return {"auth_url": auth_url, "state": state}


@router.get("/linkedin/callback")
async def linkedin_callback(
    code: str,
    state: str,
    db: AsyncSession = Depends(get_db),
    redis=Depends(get_redis),
):
    user_id = await redis.get(f"oauth:state:{state}")
    if not user_id:
        raise HTTPException(status_code=400, detail="Invalid or expired OAuth state")
    await redis.delete(f"oauth:state:{state}")

    async with httpx.AsyncClient() as client:
        token_resp = await client.post(
            "https://www.linkedin.com/oauth/v2/accessToken",
            data={
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": settings.LINKEDIN_REDIRECT_URI,
                "client_id": settings.LINKEDIN_CLIENT_ID,
                "client_secret": settings.LINKEDIN_CLIENT_SECRET,
            },
        )
        token_resp.raise_for_status()
        tokens = token_resp.json()

        me_resp = await client.get(
            "https://api.linkedin.com/v2/me",
            headers={"Authorization": f"Bearer {tokens['access_token']}"},
        )
        me_resp.raise_for_status()
        me = me_resp.json()

    await _upsert_connection(
        db=db,
        user_id=int(user_id),
        platform=Platform.LINKEDIN,
        platform_user_id=me["id"],
        platform_username=f"{me.get('localizedFirstName', '')} {me.get('localizedLastName', '')}".strip(),
        access_token=tokens["access_token"],
        refresh_token=tokens.get("refresh_token"),
    )
    return RedirectResponse(url="http://localhost:3000/connections?connected=linkedin")


# ── Mastodon OAuth 2.0 ────────────────────────────────────
@router.get("/mastodon/init", response_model=OAuthInitResponse)
async def mastodon_init(
    current_user: User = Depends(get_current_user),
    redis=Depends(get_redis),
):
    state = secrets.token_urlsafe(32)
    await redis.setex(f"oauth:state:{state}", STATE_TTL, str(current_user.id))

    auth_url = (
        f"{settings.MASTODON_INSTANCE}/oauth/authorize"
        f"?response_type=code"
        f"&client_id={settings.MASTODON_CLIENT_ID}"
        f"&redirect_uri={settings.MASTODON_REDIRECT_URI}"
        f"&scope=read%20write"
        f"&state={state}"
    )
    return {"auth_url": auth_url, "state": state}


@router.get("/mastodon/callback")
async def mastodon_callback(
    code: str,
    state: str,
    db: AsyncSession = Depends(get_db),
    redis=Depends(get_redis),
):
    user_id = await redis.get(f"oauth:state:{state}")
    if not user_id:
        raise HTTPException(status_code=400, detail="Invalid or expired OAuth state")
    await redis.delete(f"oauth:state:{state}")

    async with httpx.AsyncClient() as client:
        token_resp = await client.post(
            f"{settings.MASTODON_INSTANCE}/oauth/token",
            data={
                "grant_type": "authorization_code",
                "code": code,
                "client_id": settings.MASTODON_CLIENT_ID,
                "client_secret": settings.MASTODON_CLIENT_SECRET,
                "redirect_uri": settings.MASTODON_REDIRECT_URI,
                "scope": "read write",
            },
        )
        token_resp.raise_for_status()
        tokens = token_resp.json()

        me_resp = await client.get(
            f"{settings.MASTODON_INSTANCE}/api/v1/accounts/verify_credentials",
            headers={"Authorization": f"Bearer {tokens['access_token']}"},
        )
        me_resp.raise_for_status()
        me = me_resp.json()

    await _upsert_connection(
        db=db,
        user_id=int(user_id),
        platform=Platform.MASTODON,
        platform_user_id=me["id"],
        platform_username=f"@{me['acct']}",
        access_token=tokens["access_token"],
    )
    return RedirectResponse(url="http://localhost:3000/connections?connected=mastodon")


# ── Helpers ───────────────────────────────────────────────
async def _upsert_connection(
    db: AsyncSession,
    user_id: int,
    platform: Platform,
    platform_user_id: str,
    platform_username: str,
    access_token: str,
    refresh_token: str | None = None,
):
    result = await db.execute(
        select(SocialConnection).where(
            SocialConnection.user_id == user_id,
            SocialConnection.platform == platform,
        )
    )
    conn = result.scalar_one_or_none()
    if conn:
        conn.access_token = access_token
        conn.refresh_token = refresh_token
        conn.platform_username = platform_username
        conn.is_active = True
    else:
        conn = SocialConnection(
            user_id=user_id,
            platform=platform,
            platform_user_id=platform_user_id,
            platform_username=platform_username,
            access_token=access_token,
            refresh_token=refresh_token,
        )
        db.add(conn)
    await db.flush()
