from fastapi import APIRouter, Depends, HTTPException
from app.core.security import get_current_user
from app.core.redis import get_redis
from app.models.user import User
from app.models.schemas import QueueStats
from app.services.queue_service import QueueService

router = APIRouter()


@router.get("/stats", response_model=QueueStats)
async def queue_stats(
    current_user: User = Depends(get_current_user),
    redis=Depends(get_redis),
):
    svc = QueueService(redis)
    return await svc.get_stats()


@router.get("/job/{job_id}")
async def job_status(
    job_id: str,
    current_user: User = Depends(get_current_user),
    redis=Depends(get_redis),
):
    svc = QueueService(redis)
    job = await svc.get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@router.delete("/job/{job_id}", status_code=204)
async def cancel_job(
    job_id: str,
    current_user: User = Depends(get_current_user),
    redis=Depends(get_redis),
):
    svc = QueueService(redis)
    cancelled = await svc.cancel_job(job_id)
    if not cancelled:
        raise HTTPException(status_code=404, detail="Job not found or already processing")
