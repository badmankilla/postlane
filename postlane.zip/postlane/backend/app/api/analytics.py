from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, desc
from datetime import datetime, timezone, timedelta
from typing import List

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.user import User, Post, PostAnalytics, PostStatus
from app.models.schemas import AnalyticsSummary, DailyStats, TopPost

router = APIRouter()


@router.get("/summary", response_model=AnalyticsSummary)
async def analytics_summary(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    since = datetime.now(timezone.utc) - timedelta(days=days)

    result = await db.execute(
        select(
            func.sum(PostAnalytics.impressions).label("impressions"),
            func.sum(PostAnalytics.engagements).label("engagements"),
            func.sum(PostAnalytics.link_clicks).label("link_clicks"),
            func.avg(PostAnalytics.engagement_rate).label("avg_rate"),
            func.count(Post.id).label("post_count"),
        )
        .join(Post, PostAnalytics.post_id == Post.id)
        .where(Post.user_id == current_user.id, Post.sent_at >= since)
    )
    row = result.one()

    return AnalyticsSummary(
        total_impressions=int(row.impressions or 0),
        total_engagements=int(row.engagements or 0),
        total_posts=int(row.post_count or 0),
        avg_engagement_rate=round(float(row.avg_rate or 0), 2),
        total_link_clicks=int(row.link_clicks or 0),
        follower_gain=0,  # populated by a separate follower-sync job
        period_days=days,
    )


@router.get("/daily", response_model=List[DailyStats])
async def daily_stats(
    days: int = Query(7, ge=1, le=90),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    since = datetime.now(timezone.utc) - timedelta(days=days)

    result = await db.execute(
        select(
            func.date(Post.sent_at).label("date"),
            func.sum(PostAnalytics.impressions).label("impressions"),
            func.sum(PostAnalytics.engagements).label("engagements"),
            func.count(Post.id).label("posts_sent"),
        )
        .join(Post, PostAnalytics.post_id == Post.id)
        .where(Post.user_id == current_user.id, Post.sent_at >= since)
        .group_by(func.date(Post.sent_at))
        .order_by(func.date(Post.sent_at))
    )

    return [
        DailyStats(
            date=str(row.date),
            impressions=int(row.impressions or 0),
            engagements=int(row.engagements or 0),
            posts_sent=int(row.posts_sent or 0),
        )
        for row in result.all()
    ]


@router.get("/top-posts", response_model=List[TopPost])
async def top_posts(
    limit: int = Query(10, le=50),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Post, PostAnalytics)
        .join(PostAnalytics, PostAnalytics.post_id == Post.id)
        .where(Post.user_id == current_user.id, Post.status == PostStatus.SENT)
        .order_by(desc(PostAnalytics.impressions))
        .limit(limit)
    )

    return [
        TopPost(
            id=post.id,
            content=post.content,
            platform=post.platform,
            impressions=analytics.impressions,
            engagements=analytics.engagements,
            engagement_rate=analytics.engagement_rate,
            sent_at=post.sent_at,
        )
        for post, analytics in result.all()
    ]
