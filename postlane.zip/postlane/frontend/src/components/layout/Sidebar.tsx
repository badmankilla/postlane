'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { LayoutDashboard, PenLine, ListOrdered, BarChart2, Link2, LogOut, Layers } from 'lucide-react'
import { useAuthStore } from '@/hooks/useAuthStore'
import { useQueueStats } from '@/hooks/useApi'
import { cn } from '@/lib/utils'

const NAV = [
  { href: '/dashboard',   label: 'Dashboard',  icon: LayoutDashboard },
  { href: '/compose',     label: 'Compose',     icon: PenLine },
  { href: '/queue',       label: 'Queue',       icon: ListOrdered, badge: true },
  { href: '/analytics',   label: 'Analytics',   icon: BarChart2 },
  { href: '/connections', label: 'Connections', icon: Link2 },
]

export default function Sidebar() {
  const pathname = usePathname()
  const { user, logout } = useAuthStore()
  const { data: stats } = useQueueStats()

  return (
    <aside className="w-[220px] min-w-[220px] flex flex-col border-r"
      style={{ background: 'var(--bg2)', borderColor: 'var(--border)', height: '100vh' }}>
      <div className="flex items-center gap-3 px-5 py-6">
        <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'var(--accent)' }}>
          <Layers size={16} color="white" />
        </div>
        <div>
          <div className="text-sm font-bold tracking-tight">Postlane</div>
          <div className="text-[9px] font-mono-custom px-1.5 py-0.5 rounded"
            style={{ background: 'rgba(108,92,231,0.2)', color: 'var(--accent2)', border: '1px solid rgba(108,92,231,0.3)' }}>
            indie v1.0
          </div>
        </div>
      </div>

      <nav className="px-3 flex-1">
        <p className="text-[10px] font-semibold uppercase tracking-widest px-2 mb-2" style={{ color: 'var(--muted)' }}>Workspace</p>
        {NAV.map(({ href, label, icon: Icon, badge }) => {
          const active = pathname === href || pathname.startsWith(href + '/')
          return (
            <Link key={href} href={href}
              className={cn('flex items-center gap-2.5 px-2.5 py-2 rounded-lg mb-0.5 text-[13px] transition-all',
                active ? 'text-[color:var(--accent2)]' : 'text-[color:var(--muted)] hover:text-[color:var(--text)]')}
              style={active ? { background: 'rgba(108,92,231,0.15)' } : undefined}>
              <Icon size={15} />
              <span>{label}</span>
              {badge && stats && stats.queued > 0 && (
                <span className="ml-auto text-[9px] font-bold text-white px-1.5 py-0.5 rounded"
                  style={{ background: 'var(--accent)', fontFamily: 'DM Mono, monospace' }}>
                  {stats.queued}
                </span>
              )}
            </Link>
          )
        })}
      </nav>

      {stats && (
        <div className="mx-3 mb-3 p-3 rounded-lg" style={{ background: 'var(--bg3)', border: '1px solid var(--border)' }}>
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2 h-2 rounded-full pulse-dot" style={{ background: 'var(--green)' }} />
            <span className="text-[11px] font-mono-custom" style={{ color: 'var(--muted)' }}>Queue healthy</span>
          </div>
          <div className="text-[10px] font-mono-custom mb-1.5" style={{ color: 'var(--muted)' }}>
            {stats.queued} / 200 posts
          </div>
          <div className="h-1 rounded-full" style={{ background: 'var(--border2)' }}>
            <div className="h-full rounded-full transition-all"
              style={{ width: `${Math.min((stats.queued / 200) * 100, 100)}%`, background: 'linear-gradient(90deg, var(--accent), var(--accent2))' }} />
          </div>
          <div className="text-[10px] font-mono-custom mt-1.5" style={{ color: 'var(--green)' }}>
            {stats.on_time_rate}% on-time delivery
          </div>
        </div>
      )}

      <div className="p-3 border-t" style={{ borderColor: 'var(--border)' }}>
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-bold flex-shrink-0"
            style={{ background: 'linear-gradient(135deg, var(--accent), var(--pink))' }}>
            {user?.username?.[0]?.toUpperCase() ?? 'U'}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-[12px] font-semibold truncate">{user?.username ?? 'user'}</p>
            <p className="text-[10px] truncate" style={{ color: 'var(--muted)' }}>{user?.email}</p>
          </div>
          <button onClick={logout} className="p-1 rounded transition-colors hover:opacity-70" style={{ color: 'var(--muted)' }}>
            <LogOut size={14} />
          </button>
        </div>
      </div>
    </aside>
  )
}
