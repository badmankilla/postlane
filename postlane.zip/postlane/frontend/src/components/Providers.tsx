'use client'
import { QueryClient, QueryClientProvider } from 'react-query'
import { useState } from 'react'

export default function Providers({ children }: { children: React.ReactNode }) {
  const [qc] = useState(() => new QueryClient({
    defaultOptions: { queries: { retry: 1, staleTime: 30_000, refetchOnWindowFocus: false } },
  }))
  return <QueryClientProvider client={qc}>{children}</QueryClientProvider>
}
