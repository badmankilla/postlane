import { cn } from '@/lib/utils'

// ── Card ─────────────────────────────────────────────────
export function Card({ children, className, style }: { children: React.ReactNode; className?: string; style?: React.CSSProperties }) {
  return (
    <div className={cn('rounded-xl', className)}
      style={{ background: 'var(--bg2)', border: '1px solid var(--border)', ...style }}>
      {children}
    </div>
  )
}

// ── StatCard ──────────────────────────────────────────────
interface StatCardProps {
  label: string
  value: string | number
  delta?: string
  deltaUp?: boolean
  sub?: string
  accentColor?: string
}

export function StatCard({ label, value, delta, deltaUp = true, sub, accentColor = 'var(--accent2)' }: StatCardProps) {
  return (
    <div className="rounded-xl p-4 relative overflow-hidden"
      style={{ background: 'var(--bg2)', border: '1px solid var(--border)', borderTop: `2px solid ${accentColor}` }}>
      <p className="text-[11px] uppercase tracking-[0.8px] mb-2" style={{ color: 'var(--muted)' }}>{label}</p>
      <p className="text-3xl font-bold tracking-tight mb-1 font-mono-custom leading-none" style={{ color: accentColor }}>{value}</p>
      {delta && (
        <p className="text-[11px] font-mono-custom">
          <span style={{ color: deltaUp ? 'var(--green)' : 'var(--red)' }}>{deltaUp ? '↑' : '↓'} {delta}</span>
          {sub && <span style={{ color: 'var(--muted)' }}> · {sub}</span>}
        </p>
      )}
      {!delta && sub && <p className="text-[10px]" style={{ color: 'var(--muted)' }}>{sub}</p>}
    </div>
  )
}

// ── PlatformPill ──────────────────────────────────────────
import { PLATFORM_META } from '@/lib/utils'
import type { Platform } from '@/types'

export function PlatformPill({ platform }: { platform: Platform }) {
  const meta = PLATFORM_META[platform]
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold"
      style={{ background: meta.bg, color: meta.color }}>
      {meta.icon} {meta.label}
    </span>
  )
}

// ── StatusBadge ───────────────────────────────────────────
import { STATUS_META } from '@/lib/utils'
import type { PostStatus } from '@/types'

export function StatusBadge({ status }: { status: PostStatus }) {
  const meta = STATUS_META[status]
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold font-mono-custom"
      style={{ background: meta.bg, color: meta.color }}>
      {meta.label}
    </span>
  )
}

// ── Button ────────────────────────────────────────────────
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'ghost' | 'danger'
  size?: 'sm' | 'md'
  children: React.ReactNode
}

export function Button({ variant = 'primary', size = 'md', children, className, ...props }: ButtonProps) {
  const base = 'inline-flex items-center gap-1.5 font-semibold rounded-lg transition-all cursor-pointer border-none'
  const sizes = { sm: 'px-3 py-1.5 text-[11px]', md: 'px-4 py-2 text-[12px]' }
  const variants = {
    primary: 'text-white hover:-translate-y-px',
    ghost:   'hover:opacity-80',
    danger:  'hover:opacity-80',
  }
  const variantStyles = {
    primary: { background: 'var(--accent)' },
    ghost:   { background: 'transparent', color: 'var(--muted)', border: '1px solid var(--border2)' },
    danger:  { background: 'rgba(248,113,113,0.12)', color: 'var(--red)', border: '1px solid rgba(248,113,113,0.2)' },
  }

  return (
    <button className={cn(base, sizes[size], variants[variant], className)}
      style={variantStyles[variant]} {...props}>
      {children}
    </button>
  )
}

// ── TopBar ────────────────────────────────────────────────
export function TopBar({ title, sub, children }: { title: string; sub?: string; children?: React.ReactNode }) {
  return (
    <div className="flex items-center gap-4 px-7 py-4 border-b flex-shrink-0"
      style={{ background: 'var(--bg2)', borderColor: 'var(--border)' }}>
      <div>
        <h1 className="text-[16px] font-semibold">{title}</h1>
        {sub && <p className="text-[12px] font-mono-custom" style={{ color: 'var(--muted)' }}>{sub}</p>}
      </div>
      {children && <div className="ml-auto flex items-center gap-3">{children}</div>}
    </div>
  )
}

// ── EmptyState ────────────────────────────────────────────
export function EmptyState({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 gap-3">
      <div className="text-4xl opacity-30">{icon}</div>
      <p className="text-[15px] font-semibold" style={{ color: 'var(--text)' }}>{title}</p>
      <p className="text-[13px] text-center max-w-xs" style={{ color: 'var(--muted)' }}>{description}</p>
    </div>
  )
}

// ── Spinner ───────────────────────────────────────────────
export function Spinner() {
  return (
    <div className="flex items-center justify-center py-20">
      <div className="w-6 h-6 rounded-full border-2 border-t-transparent animate-spin"
        style={{ borderColor: 'var(--accent)', borderTopColor: 'transparent' }} />
    </div>
  )
}

// ── TechStrip ─────────────────────────────────────────────
const TECHS = ['Next.js 14', 'FastAPI', 'PostgreSQL', 'Redis', 'BullMQ', 'OAuth 2.0', 'JWT', 'Tailwind CSS']

export function TechStrip() {
  return (
    <div className="flex items-center gap-2 flex-wrap px-7 py-2.5 border-t flex-shrink-0"
      style={{ background: 'var(--bg2)', borderColor: 'var(--border)' }}>
      <span className="text-[10px] font-mono-custom mr-1" style={{ color: 'var(--muted)' }}>Stack:</span>
      {TECHS.map(t => (
        <span key={t} className="text-[10px] font-mono-custom px-2 py-0.5 rounded"
          style={{ background: 'rgba(255,255,255,0.05)', color: 'var(--muted)', border: '1px solid var(--border)' }}>
          {t}
        </span>
      ))}
      <span className="ml-auto text-[10px] font-mono-custom" style={{ color: 'var(--muted)' }}>
        10 concurrent sessions · 200+ posts · 99.9% delivery
      </span>
    </div>
  )
}
