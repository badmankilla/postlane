import { useQuery, useMutation, useQueryClient } from 'react-query'
import api from '@/lib/api'
import type { Post, QueueStats, AnalyticsSummary, DailyStats, TopPost, SocialConnection, PostCreatePayload } from '@/types'

// Posts
export function usePosts(status?: string, platform?: string) {
  return useQuery<Post[]>(['posts', status, platform], async () => {
    const params = new URLSearchParams()
    if (status) params.set('status', status)
    if (platform) params.set('platform', platform)
    const res = await api.get(`/api/posts?${params}`)
    return res.data
  })
}

export function useCreatePost() {
  const qc = useQueryClient()
  return useMutation(
    async (payload: PostCreatePayload) => {
      const res = await api.post('/api/posts', payload)
      return res.data as Post[]
    },
    { onSuccess: () => qc.invalidateQueries('posts') }
  )
}

export function useDeletePost() {
  const qc = useQueryClient()
  return useMutation(
    async (id: number) => { await api.delete(`/api/posts/${id}`) },
    { onSuccess: () => qc.invalidateQueries('posts') }
  )
}

// Queue
export function useQueueStats() {
  return useQuery<QueueStats>('queue-stats', async () => {
    const res = await api.get('/api/queue/stats')
    return res.data
  }, { refetchInterval: 10_000 })
}

// Analytics
export function useAnalyticsSummary(days = 30) {
  return useQuery<AnalyticsSummary>(['analytics-summary', days], async () => {
    const res = await api.get(`/api/analytics/summary?days=${days}`)
    return res.data
  })
}

export function useDailyStats(days = 7) {
  return useQuery<DailyStats[]>(['daily-stats', days], async () => {
    const res = await api.get(`/api/analytics/daily?days=${days}`)
    return res.data
  })
}

export function useTopPosts(limit = 5) {
  return useQuery<TopPost[]>(['top-posts', limit], async () => {
    const res = await api.get(`/api/analytics/top-posts?limit=${limit}`)
    return res.data
  })
}

// Connections
export function useConnections() {
  return useQuery<SocialConnection[]>('connections', async () => {
    const res = await api.get('/api/connections')
    return res.data
  })
}

export function useDisconnect() {
  const qc = useQueryClient()
  return useMutation(
    async (platform: string) => { await api.delete(`/api/connections/${platform}`) },
    { onSuccess: () => qc.invalidateQueries('connections') }
  )
}
