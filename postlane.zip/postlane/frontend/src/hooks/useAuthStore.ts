import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import Cookies from 'js-cookie'
import type { User } from '@/types'

interface AuthState {
  user: User | null
  token: string | null
  setAuth: (user: User, token: string) => void
  logout: () => void
  isAuthenticated: () => boolean
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      token: null,
      setAuth: (user, token) => {
        Cookies.set('token', token, { expires: 1 })
        localStorage.setItem('token', token)
        set({ user, token })
      },
      logout: () => {
        Cookies.remove('token')
        localStorage.removeItem('token')
        set({ user: null, token: null })
        window.location.href = '/login'
      },
      isAuthenticated: () => !!get().token,
    }),
    { name: 'postlane-auth', partialize: (s) => ({ user: s.user, token: s.token }) }
  )
)
