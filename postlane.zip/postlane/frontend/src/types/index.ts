export type Platform = 'twitter' | 'linkedin' | 'mastodon'
export type PostStatus = 'draft' | 'queued' | 'processing' | 'sent' | 'failed'

export interface User {
  id: number
  email: string
  username: string
  full_name?: string
  avatar_url?: string
  created_at: string
}

export interface PostAnalytics {
  impressions: number
  engagements: number
  likes: number
  reposts: number
  replies: number
  link_clicks: number
  engagement_rate: number
  fetched_at: string
}

export interface Post {
  id: number
  content: string
  platform: Platform
  status: PostStatus
  scheduled_at: string
  sent_at?: string
  platform_post_id?: string
  error_message?: string
  retry_count: number
  job_id?: string
  media_urls: string[]
  created_at: string
  analytics: PostAnalytics[]
}

export interface QueueStats {
  queued: number
  processing: number
  completed: number
  failed: number
  on_time_rate: number
  next_delivery_in_seconds?: number
  worker_count: number
}

export interface AnalyticsSummary {
  total_impressions: number
  total_engagements: number
  total_posts: number
  avg_engagement_rate: number
  total_link_clicks: number
  follower_gain: number
  period_days: number
}

export interface DailyStats {
  date: string
  impressions: number
  engagements: number
  posts_sent: number
}

export interface TopPost {
  id: number
  content: string
  platform: Platform
  impressions: number
  engagements: number
  engagement_rate: number
  sent_at?: string
}

export interface SocialConnection {
  id: number
  platform: Platform
  platform_username?: string
  is_active: boolean
  rate_limit_remaining?: number
  rate_limit_reset_at?: string
  created_at: string
}

export interface PostCreatePayload {
  content: string
  platforms: Platform[]
  scheduled_at: string
  media_urls?: string[]
}
