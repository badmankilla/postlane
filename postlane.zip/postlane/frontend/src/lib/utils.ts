import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'
import { format, formatDistanceToNow, parseISO } from 'date-fns'
import type { Platform, PostStatus } from '@/types'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatDate(date: string) {
  return format(parseISO(date), 'MMM d, yyyy')
}

export function formatDateTime(date: string) {
  return format(parseISO(date), 'MMM d · h:mm a')
}

export function formatRelative(date: string) {
  return formatDistanceToNow(parseISO(date), { addSuffix: true })
}

export function formatNumber(n: number) {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000)     return `${(n / 1_000).toFixed(1)}K`
  return n.toString()
}

export const PLATFORM_META: Record<Platform, { label: string; icon: string; color: string; bg: string; charLimit: number }> = {
  twitter:  { label: 'Twitter/X', icon: '𝕏', color: '#1da1f2', bg: 'rgba(29,161,242,0.12)', charLimit: 280 },
  linkedin: { label: 'LinkedIn',  icon: 'in', color: '#0077b5', bg: 'rgba(0,119,181,0.12)',  charLimit: 3000 },
  mastodon: { label: 'Mastodon', icon: '🐘', color: '#6364ff', bg: 'rgba(99,100,255,0.12)', charLimit: 500 },
}

export const STATUS_META: Record<PostStatus, { label: string; color: string; bg: string }> = {
  draft:      { label: 'Draft',      color: '#7a7a8e', bg: 'rgba(122,122,142,0.12)' },
  queued:     { label: 'Queued',     color: '#fbbf24', bg: 'rgba(251,191,36,0.12)'  },
  processing: { label: 'Processing', color: '#38bdf8', bg: 'rgba(56,189,248,0.12)'  },
  sent:       { label: 'Sent',       color: '#7a7a8e', bg: 'rgba(255,255,255,0.06)' },
  failed:     { label: 'Failed',     color: '#f87171', bg: 'rgba(248,113,113,0.12)' },
}
