'use client'
import Link from 'next/link'
import { Plus, RefreshCw } from 'lucide-react'
import AppShell from '@/components/layout/AppShell'
import { StatCard, Card, PlatformPill, StatusBadge, TopBar, TechStrip, Spinner, EmptyState, Button } from '@/components/ui'
import { usePosts, useQueueStats, useAnalyticsSummary, useDailyStats } from '@/hooks/useApi'
import { formatDateTime, formatNumber, PLATFORM_META } from '@/lib/utils'
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid
} from 'recharts'

export default function DashboardPage() {
  const { data: posts, isLoading: postsLoading, refetch } = usePosts(undefined, undefined)
  const { data: stats } = useQueueStats()
  const { data: summary } = useAnalyticsSummary(30)
  const { data: daily } = useDailyStats(7)

  const recentPosts = posts?.slice(0, 8) ?? []

  return (
    <AppShell>
      <TopBar title="Dashboard" sub="Last 30 days · all platforms">
        <Button variant="ghost" size="sm" onClick={() => refetch()}>
          <RefreshCw size={12} /> Refresh
        </Button>
        <Link href="/compose">
          <Button size="sm">
            <Plus size={13} /> New Post
          </Button>
        </Link>
      </TopBar>

      <div className="flex-1 overflow-y-auto p-7 flex flex-col gap-5">
        {/* Metric cards */}
        <div className="grid grid-cols-4 gap-3">
          <StatCard
            label="Posts Sent"
            value={formatNumber(summary?.total_posts ?? 214)}
            delta="18%"
            sub="vs last period"
            accentColor="var(--green)"
          />
          <StatCard
            label="Total Impressions"
            value={formatNumber(summary?.total_impressions ?? 48200)}
            delta="34%"
            sub="all platforms"
            accentColor="var(--accent2)"
          />
          <StatCard
            label="Engagements"
            value={formatNumber(summary?.total_engagements ?? 3700)}
            delta="22%"
            sub={`${summary?.avg_engagement_rate ?? 7.7}% avg rate`}
            accentColor="var(--amber)"
          />
          <StatCard
            label="Queue Depth"
            value={stats?.queued ?? 134}
            delta={undefined}
            sub={`${stats?.on_time_rate ?? 99.1}% on-time delivery`}
            accentColor="var(--blue)"
          />
        </div>

        {/* Charts row */}
        <div className="grid grid-cols-3 gap-3">
          {/* Impressions chart */}
          <Card className="col-span-2 p-5">
            <div className="flex items-center justify-between mb-4">
              <p className="text-[13px] font-semibold">Impressions — last 7 days</p>
              <div className="flex items-center gap-4">
                {Object.entries(PLATFORM_META).map(([p, m]) => (
                  <span key={p} className="flex items-center gap-1.5 text-[11px]" style={{ color: 'var(--muted)' }}>
                    <span className="w-2 h-2 rounded-full" style={{ background: m.color }} />
                    {m.label}
                  </span>
                ))}
              </div>
            </div>
            <ResponsiveContainer width="100%" height={140}>
              <BarChart data={daily ?? MOCK_DAILY} barSize={10} barGap={4}>
                <CartesianGrid vertical={false} stroke="rgba(255,255,255,0.04)" />
                <XAxis dataKey="date" tick={{ fill: 'var(--muted)', fontSize: 10, fontFamily: 'DM Mono' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: 'var(--muted)', fontSize: 10, fontFamily: 'DM Mono' }} axisLine={false} tickLine={false} width={32} />
                <Tooltip contentStyle={{ background: 'var(--bg3)', border: '1px solid var(--border2)', borderRadius: 8, fontSize: 12 }}
                  labelStyle={{ color: 'var(--text)' }} cursor={{ fill: 'rgba(255,255,255,0.03)' }} />
                <Bar dataKey="impressions" fill="#6c5ce7" radius={[3, 3, 0, 0]} opacity={0.9} />
              </BarChart>
            </ResponsiveContainer>
          </Card>

          {/* Platform breakdown */}
          <Card className="p-5">
            <p className="text-[13px] font-semibold mb-4">By platform</p>
            <div className="flex flex-col gap-4">
              {Object.entries(PLATFORM_META).map(([p, m]) => {
                const pcts: Record<string, number> = { twitter: 72, linkedin: 46, mastodon: 21 }
                return (
                  <div key={p}>
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded flex items-center justify-center text-[11px]"
                          style={{ background: m.bg }}>{m.icon}</span>
                        <span className="text-[12px] font-semibold">{m.label}</span>
                      </div>
                      <span className="text-[11px] font-mono-custom" style={{ color: 'var(--muted)' }}>{pcts[p]}%</span>
                    </div>
                    <div className="h-1 rounded-full" style={{ background: 'var(--border2)' }}>
                      <div className="h-full rounded-full" style={{ width: `${pcts[p]}%`, background: m.color }} />
                    </div>
                  </div>
                )
              })}
            </div>
          </Card>
        </div>

        {/* Recent posts table */}
        <Card>
          <div className="flex items-center justify-between px-5 py-4 border-b" style={{ borderColor: 'var(--border)' }}>
            <p className="text-[13px] font-semibold">Recent &amp; upcoming posts</p>
            <span className="text-[11px] font-mono-custom" style={{ color: 'var(--muted)' }}>
              BullMQ · {stats?.worker_count ?? 10} workers
            </span>
          </div>

          {postsLoading ? <Spinner /> : recentPosts.length === 0 ? (
            <EmptyState icon="📭" title="No posts yet" description="Schedule your first post to get started" />
          ) : (
            <div>
              <div className="grid px-5 py-2.5 border-b" style={{ borderColor: 'var(--border)', gridTemplateColumns: '2fr 1fr 1fr 1fr 80px' }}>
                {['Content', 'Platform', 'Scheduled', 'Status', 'Impressions'].map(h => (
                  <p key={h} className="text-[10px] uppercase tracking-[0.8px]" style={{ color: 'var(--muted)' }}>{h}</p>
                ))}
              </div>
              {recentPosts.map(post => (
                <div key={post.id} className="grid px-5 py-3 border-b items-center transition-colors hover:bg-white/[0.02] cursor-pointer"
                  style={{ borderColor: 'var(--border)', gridTemplateColumns: '2fr 1fr 1fr 1fr 80px' }}>
                  <div>
                    <p className="text-[12px] truncate max-w-[280px]">{post.content}</p>
                    <p className="text-[10px] font-mono-custom mt-0.5" style={{ color: 'var(--muted)' }}>{post.content.length} chars</p>
                  </div>
                  <PlatformPill platform={post.platform} />
                  <p className="text-[11px] font-mono-custom" style={{ color: 'var(--muted)' }}>{formatDateTime(post.scheduled_at)}</p>
                  <StatusBadge status={post.status} />
                  <p className="text-[12px] font-mono-custom font-medium text-right">
                    {post.analytics?.[0] ? formatNumber(post.analytics[0].impressions) : '—'}
                  </p>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>

      <TechStrip />
    </AppShell>
  )
}

const MOCK_DAILY = [
  { date: 'Mon', impressions: 5200 },
  { date: 'Tue', impressions: 7800 },
  { date: 'Wed', impressions: 4400 },
  { date: 'Thu', impressions: 9100 },
  { date: 'Fri', impressions: 6700 },
  { date: 'Sat', impressions: 11000 },
  { date: 'Sun', impressions: 8800 },
]
