import type { Metadata } from 'next'
import './globals.css'
import Providers from '@/components/Providers'
import { Toaster } from 'react-hot-toast'

export const metadata: Metadata = {
  title: 'Postlane — Social Media Scheduler',
  description: 'Schedule posts across Twitter/X, LinkedIn, and Mastodon.',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Providers>
          {children}
          <Toaster
            position="bottom-right"
            toastOptions={{
              style: {
                background: '#13151b',
                color: '#e8e6f0',
                border: '1px solid rgba(0,214,143,0.3)',
                borderRadius: '10px',
                fontFamily: 'Syne, sans-serif',
                fontSize: '13px',
              },
            }}
          />
        </Providers>
      </body>
    </html>
  )
}
