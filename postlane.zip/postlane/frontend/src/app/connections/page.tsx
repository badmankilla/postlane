'use client'
import { useEffect } from 'react'
import { useSearchParams } from 'next/navigation'
import toast from 'react-hot-toast'
import { Link2Off, ExternalLink, Shield, Zap } from 'lucide-react'
import AppShell from '@/components/layout/AppShell'
import { Card, TopBar, Button, TechStrip, Spinner } from '@/components/ui'
import { useConnections, useDisconnect } from '@/hooks/useApi'
import api from '@/lib/api'
import type { Platform } from '@/types'

const PLATFORMS: {
  id: Platform
  name: string
  icon: string
  color: string
  bg: string
  description: string
  scopes: string[]
}[] = [
  {
    id: 'twitter',
    name: 'Twitter / X',
    icon: '𝕏',
    color: '#1da1f2',
    bg: 'rgba(29,161,242,0.12)',
    description: 'Post tweets, threads, and media. Up to 280 chars per post.',
    scopes: ['tweet.read', 'tweet.write', 'users.read', 'offline.access'],
  },
  {
    id: 'linkedin',
    name: 'LinkedIn',
    icon: 'in',
    color: '#0077b5',
    bg: 'rgba(0,119,181,0.12)',
    description: 'Share articles and posts to your LinkedIn profile or company page.',
    scopes: ['r_liteprofile', 'w_member_social'],
  },
  {
    id: 'mastodon',
    name: 'Mastodon',
    icon: '🐘',
    color: '#6364ff',
    bg: 'rgba(99,100,255,0.12)',
    description: 'Publish toots to any Mastodon instance. Up to 500 chars per post.',
    scopes: ['read', 'write'],
  },
]

const COMING = [
  { name: 'Instagram', icon: '📸', color: '#e4405f' },
  { name: 'Bluesky',   icon: '☁️', color: '#1083fe' },
  { name: 'Threads',   icon: '@',  color: '#888'    },
]

export default function ConnectionsPage() {
  const { data: connections, isLoading, refetch } = useConnections()
  const disconnect = useDisconnect()
  const searchParams = useSearchParams()

  // Show success toast when redirected back from OAuth
  useEffect(() => {
    const connected = searchParams.get('connected')
    if (connected) {
      toast.success(`${connected} connected successfully!`)
      refetch()
    }
  }, [searchParams, refetch])

  const getConnection = (platform: Platform) =>
    connections?.find(c => c.platform === platform && c.is_active)

  const handleConnect = async (platform: Platform) => {
    try {
      const res = await api.get(`/api/connections/${platform}/init`)
      window.location.href = res.data.auth_url
    } catch {
      toast.error('Could not start OAuth flow. Check your API credentials.')
    }
  }

  const handleDisconnect = async (platform: Platform) => {
    try {
      await disconnect.mutateAsync(platform)
      toast.success(`${platform} disconnected`)
    } catch {
      toast.error('Failed to disconnect')
    }
  }

  return (
    <AppShell>
      <TopBar title="Platform connections" sub="OAuth 2.0 · API credentials · Rate limits">
        <button className="text-[12px] font-mono-custom flex items-center gap-1.5 px-3 py-1.5 rounded-lg"
          style={{ color: 'var(--muted)', background: 'var(--bg3)', border: '1px solid var(--border)' }}>
          <Shield size={12} /> All tokens encrypted at rest
        </button>
      </TopBar>

      <div className="flex-1 overflow-y-auto p-7 flex flex-col gap-6">

        {/* Security notice */}
        <div className="flex items-center gap-3 px-4 py-3 rounded-xl"
          style={{ background: 'rgba(108,92,231,0.06)', border: '1px solid rgba(108,92,231,0.15)' }}>
          <Shield size={14} style={{ color: 'var(--accent2)', flexShrink: 0 }} />
          <p className="text-[12px]" style={{ color: 'var(--muted)' }}>
            Postlane uses <span style={{ color: 'var(--accent2)', fontWeight: 600 }}>OAuth 2.0</span> — your passwords are never stored.
            Tokens are encrypted at rest in PostgreSQL and auto-refreshed before expiry.
          </p>
        </div>

        {/* Active platforms */}
        <div>
          <h2 className="text-[13px] font-semibold mb-4">Supported platforms</h2>
          {isLoading ? <Spinner /> : (
            <div className="grid grid-cols-3 gap-4">
              {PLATFORMS.map(platform => {
                const conn = getConnection(platform.id)
                const connected = !!conn
                return (
                  <Card key={platform.id} className="p-5">
                    {/* Header */}
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl flex items-center justify-center text-lg font-bold flex-shrink-0"
                          style={{ background: platform.bg, color: platform.color }}>
                          {platform.icon}
                        </div>
                        <div>
                          <p className="text-[14px] font-semibold">{platform.name}</p>
                          <p className="text-[11px] font-mono-custom mt-0.5"
                            style={{ color: connected ? 'var(--green)' : 'var(--muted)' }}>
                            {connected ? '● Connected' : '○ Not connected'}
                          </p>
                        </div>
                      </div>
                      {connected ? (
                        <Button variant="ghost" size="sm" onClick={() => handleDisconnect(platform.id)}>
                          <Link2Off size={11} /> Disconnect
                        </Button>
                      ) : (
                        <Button size="sm" onClick={() => handleConnect(platform.id)}>
                          <ExternalLink size={11} /> Connect
                        </Button>
                      )}
                    </div>

                    <p className="text-[12px] mb-4" style={{ color: 'var(--muted)' }}>{platform.description}</p>

                    {/* Connection details */}
                    {connected && conn ? (
                      <div className="space-y-2 mb-4">
                        <div className="flex items-center justify-between">
                          <span className="text-[11px]" style={{ color: 'var(--muted)' }}>Account</span>
                          <span className="text-[11px] font-mono-custom">{conn.platform_username ?? '—'}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-[11px]" style={{ color: 'var(--muted)' }}>Rate limit</span>
                          <span className="text-[11px] font-mono-custom" style={{ color: 'var(--green)' }}>
                            {conn.rate_limit_remaining ?? '—'} remaining
                          </span>
                        </div>
                      </div>
                    ) : null}

                    {/* Rate limit bar (when connected) */}
                    {connected && conn?.rate_limit_remaining != null && (
                      <div className="mb-4">
                        <div className="flex items-center justify-between text-[10px] mb-1" style={{ color: 'var(--muted)' }}>
                          <span>API quota</span>
                          <span>{conn.rate_limit_remaining} / 300</span>
                        </div>
                        <div className="h-1 rounded-full" style={{ background: 'var(--border2)' }}>
                          <div className="h-full rounded-full transition-all"
                            style={{
                              width: `${(conn.rate_limit_remaining / 300) * 100}%`,
                              background: conn.rate_limit_remaining > 100 ? 'var(--green)' : conn.rate_limit_remaining > 50 ? 'var(--amber)' : 'var(--red)',
                            }} />
                        </div>
                      </div>
                    )}

                    {/* Scopes */}
                    <div className="border-t pt-3" style={{ borderColor: 'var(--border)' }}>
                      <p className="text-[10px] uppercase tracking-wider mb-2" style={{ color: 'var(--muted)' }}>OAuth scopes</p>
                      <div className="flex flex-wrap gap-1">
                        {platform.scopes.map(s => (
                          <span key={s} className="text-[9px] font-mono-custom px-1.5 py-0.5 rounded"
                            style={{ background: 'var(--bg3)', color: 'var(--muted)', border: '1px solid var(--border)' }}>
                            {s}
                          </span>
                        ))}
                      </div>
                    </div>
                  </Card>
                )
              })}
            </div>
          )}
        </div>

        {/* Coming soon */}
        <div>
          <h2 className="text-[13px] font-semibold mb-4" style={{ color: 'var(--muted)' }}>Coming soon</h2>
          <div className="grid grid-cols-3 gap-4">
            {COMING.map(p => (
              <Card key={p.name} className="p-5 opacity-50">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center text-lg flex-shrink-0"
                    style={{ background: 'rgba(255,255,255,0.05)' }}>
                    {p.icon}
                  </div>
                  <div>
                    <p className="text-[14px] font-semibold">{p.name}</p>
                    <p className="text-[11px] font-mono-custom mt-0.5" style={{ color: 'var(--muted)' }}>Coming soon</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Technical notes */}
        <Card className="p-5">
          <div className="flex items-center gap-2 mb-3">
            <Zap size={14} style={{ color: 'var(--accent2)' }} />
            <p className="text-[13px] font-semibold">How OAuth works in Postlane</p>
          </div>
          <div className="grid grid-cols-3 gap-4 text-[12px]" style={{ color: 'var(--muted)' }}>
            <div>
              <p className="font-semibold mb-1" style={{ color: 'var(--text)' }}>1. Authorization</p>
              <p>You're redirected to the platform's OAuth page. Postlane never sees your password.</p>
            </div>
            <div>
              <p className="font-semibold mb-1" style={{ color: 'var(--text)' }}>2. Token exchange</p>
              <p>FastAPI exchanges the auth code for access + refresh tokens via the platform's token endpoint.</p>
            </div>
            <div>
              <p className="font-semibold mb-1" style={{ color: 'var(--text)' }}>3. Secure storage</p>
              <p>Tokens are encrypted and stored in PostgreSQL. The worker uses them at publish time, refreshing as needed.</p>
            </div>
          </div>
        </Card>
      </div>
      <TechStrip />
    </AppShell>
  )
}
