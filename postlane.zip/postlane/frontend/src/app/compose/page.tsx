'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import toast from 'react-hot-toast'
import { Clock, Send, X, Eye } from 'lucide-react'
import AppShell from '@/components/layout/AppShell'
import { Card, TopBar, Button, TechStrip } from '@/components/ui'
import { useCreatePost, useConnections } from '@/hooks/useApi'
import { PLATFORM_META } from '@/lib/utils'
import { useAuthStore } from '@/hooks/useAuthStore'
import type { Platform } from '@/types'

const schema = z.object({
  content: z.string().min(1, 'Content is required').max(500, 'Too long'),
  scheduled_at: z.string().min(1, 'Schedule time is required'),
  timezone: z.string(),
})
type Form = z.infer<typeof schema>

export default function ComposePage() {
  const router = useRouter()
  const { user } = useAuthStore()
  const { data: connections } = useConnections()
  const createPost = useCreatePost()

  const [selectedPlatforms, setSelectedPlatforms] = useState<Platform[]>(['twitter'])
  const [charCount, setCharCount] = useState(0)

  const { register, handleSubmit, watch, formState: { errors } } = useForm<Form>({
    resolver: zodResolver(schema),
    defaultValues: { timezone: 'UTC', scheduled_at: defaultScheduleTime() },
  })

  const content = watch('content') ?? ''

  const togglePlatform = (p: Platform) => {
    setSelectedPlatforms(prev =>
      prev.includes(p) ? prev.filter(x => x !== p) : [...prev, p]
    )
  }

  const onSubmit = async (data: Form) => {
    if (selectedPlatforms.length === 0) {
      toast.error('Select at least one platform')
      return
    }
    try {
      await createPost.mutateAsync({
        content: data.content,
        platforms: selectedPlatforms,
        scheduled_at: new Date(data.scheduled_at).toISOString(),
      })
      toast.success(`Scheduled across ${selectedPlatforms.length} platform${selectedPlatforms.length > 1 ? 's' : ''}!`)
      router.push('/queue')
    } catch (e: any) {
      toast.error(e.response?.data?.detail ?? 'Failed to schedule post')
    }
  }

  const connectedPlatforms = new Set(connections?.map(c => c.platform) ?? [])
  const charLimit = Math.min(...selectedPlatforms.map(p => PLATFORM_META[p].charLimit))

  return (
    <AppShell>
      <TopBar title="Compose post" sub="Schedule across multiple platforms">
        <Button variant="ghost" size="sm" onClick={() => router.back()}>
          <X size={13} /> Cancel
        </Button>
        <Button size="sm" onClick={handleSubmit(onSubmit)} disabled={createPost.isLoading}>
          <Clock size={13} /> {createPost.isLoading ? 'Scheduling…' : 'Schedule post'}
        </Button>
      </TopBar>

      <div className="flex-1 overflow-y-auto">
        <div className="grid h-full" style={{ gridTemplateColumns: '1fr 340px' }}>

          {/* Left: Editor */}
          <div className="p-7 border-r flex flex-col gap-5" style={{ borderColor: 'var(--border)' }}>

            {/* Platform toggles */}
            <div>
              <p className="text-[11px] uppercase tracking-wider mb-3" style={{ color: 'var(--muted)' }}>Publish to</p>
              <div className="flex gap-2 flex-wrap">
                {(Object.entries(PLATFORM_META) as [Platform, typeof PLATFORM_META[Platform]][]).map(([p, m]) => {
                  const on = selectedPlatforms.includes(p)
                  const connected = connectedPlatforms.has(p)
                  return (
                    <button key={p} onClick={() => connected && togglePlatform(p)}
                      title={!connected ? 'Connect this platform first' : undefined}
                      className="flex items-center gap-2 px-3 py-2 rounded-lg text-[12px] font-semibold transition-all border"
                      style={{
                        background: on ? m.bg : 'transparent',
                        color: on ? m.color : 'var(--muted)',
                        borderColor: on ? m.color + '55' : 'var(--border2)',
                        opacity: connected ? 1 : 0.4,
                        cursor: connected ? 'pointer' : 'not-allowed',
                      }}>
                      {m.icon} {m.label}
                      {!connected && <span className="text-[9px]">(not connected)</span>}
                    </button>
                  )
                })}
              </div>
            </div>

            {/* Text area */}
            <div>
              <p className="text-[11px] uppercase tracking-wider mb-2" style={{ color: 'var(--muted)' }}>Post content</p>
              <textarea
                {...register('content')}
                rows={7}
                placeholder="What's on your mind? Share your indie hacker journey…"
                onChange={e => setCharCount(e.target.value.length)}
                className="w-full resize-none text-[14px] leading-relaxed"
                style={{
                  background: 'var(--bg2)',
                  border: `1px solid ${errors.content ? 'var(--red)' : 'var(--border2)'}`,
                  borderRadius: 12,
                  padding: '14px 16px',
                  color: 'var(--text)',
                  fontFamily: 'Syne, sans-serif',
                  outline: 'none',
                }}
              />
              <div className="flex items-center justify-between mt-1">
                {errors.content
                  ? <p className="text-[11px]" style={{ color: 'var(--red)' }}>{errors.content.message}</p>
                  : <span />}
                <p className="text-[11px] font-mono-custom"
                  style={{ color: charCount > charLimit ? 'var(--red)' : 'var(--muted)' }}>
                  {charCount} / {charLimit}
                </p>
              </div>
            </div>

            {/* Schedule fields */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-[11px] uppercase tracking-wider mb-2" style={{ color: 'var(--muted)' }}>Date &amp; Time</p>
                <input
                  {...register('scheduled_at')}
                  type="datetime-local"
                  style={{ background: 'var(--bg2)', border: `1px solid ${errors.scheduled_at ? 'var(--red)' : 'var(--border2)'}` }}
                />
                {errors.scheduled_at && <p className="text-[11px] mt-1" style={{ color: 'var(--red)' }}>{errors.scheduled_at.message}</p>}
              </div>
              <div>
                <p className="text-[11px] uppercase tracking-wider mb-2" style={{ color: 'var(--muted)' }}>Timezone</p>
                <select {...register('timezone')} style={{ background: 'var(--bg2)' }}>
                  {['UTC', 'America/New_York', 'America/Los_Angeles', 'Europe/London', 'Europe/Berlin', 'Asia/Singapore', 'Asia/Tokyo'].map(tz => (
                    <option key={tz} value={tz}>{tz}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Best time hint */}
            <div className="flex items-center gap-3 px-4 py-3 rounded-xl"
              style={{ background: 'rgba(108,92,231,0.08)', border: '1px solid rgba(108,92,231,0.2)' }}>
              <Clock size={14} style={{ color: 'var(--accent2)', flexShrink: 0 }} />
              <p className="text-[12px]" style={{ color: 'var(--muted)' }}>
                Best time detected: <span style={{ color: 'var(--accent2)', fontWeight: 600 }}>Tue 2:00 PM</span> based on audience engagement
              </p>
            </div>
          </div>

          {/* Right: Preview + job info */}
          <div className="p-5 flex flex-col gap-4" style={{ background: 'var(--bg2)' }}>
            <div>
              <p className="text-[11px] uppercase tracking-wider mb-3 flex items-center gap-1.5" style={{ color: 'var(--muted)' }}>
                <Eye size={11} /> Preview
              </p>
              <Card className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center text-[11px] font-bold"
                    style={{ background: 'linear-gradient(135deg, var(--accent), var(--pink))' }}>
                    {user?.username?.[0]?.toUpperCase() ?? 'U'}
                  </div>
                  <div>
                    <p className="text-[13px] font-semibold">{user?.username ?? 'you'}</p>
                    <p className="text-[11px]" style={{ color: 'var(--muted)' }}>just now</p>
                  </div>
                </div>
                <p className="text-[13px] leading-relaxed" style={{ color: content ? 'var(--text)' : 'var(--muted)' }}>
                  {content || 'Start typing your post…'}
                </p>
                <div className="flex flex-wrap gap-1 mt-2">
                  {selectedPlatforms.map(p => (
                    <span key={p} className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: PLATFORM_META[p].bg, color: PLATFORM_META[p].color }}>
                      {PLATFORM_META[p].icon} {PLATFORM_META[p].label}
                    </span>
                  ))}
                </div>
              </Card>
            </div>

            {/* BullMQ job preview */}
            <div>
              <p className="text-[11px] uppercase tracking-wider mb-3" style={{ color: 'var(--muted)' }}>Queue preview</p>
              <Card className="p-4">
                <p className="text-[11px] mb-2" style={{ color: 'var(--muted)' }}>BullMQ job metadata</p>
                <div className="text-[11px] leading-loose font-mono-custom" style={{ color: 'var(--accent2)' }}>
                  {[
                    ['jobId', `post_${Date.now().toString(36)}`],
                    ['priority', 'normal'],
                    ['attempts', `0 / ${3} max`],
                    ['backoff', 'exponential'],
                    ['platforms', selectedPlatforms.join(', ') || 'none'],
                  ].map(([k, v]) => (
                    <div key={k}>
                      <span style={{ color: 'var(--accent2)' }}>{k}:</span>{' '}
                      <span style={{ color: 'var(--text)' }}>{v}</span>
                    </div>
                  ))}
                </div>
              </Card>
            </div>

            {/* Platforms status */}
            <div>
              <p className="text-[11px] uppercase tracking-wider mb-3" style={{ color: 'var(--muted)' }}>Platform status</p>
              <div className="flex flex-col gap-2">
                {(Object.entries(PLATFORM_META) as [Platform, typeof PLATFORM_META[Platform]][]).map(([p, m]) => {
                  const connected = connectedPlatforms.has(p)
                  return (
                    <div key={p} className="flex items-center justify-between px-3 py-2 rounded-lg"
                      style={{ background: 'var(--bg3)', border: '1px solid var(--border)' }}>
                      <div className="flex items-center gap-2">
                        <span className="text-[13px]">{m.icon}</span>
                        <span className="text-[12px] font-semibold">{m.label}</span>
                      </div>
                      <span className="text-[10px] font-mono-custom" style={{ color: connected ? 'var(--green)' : 'var(--muted)' }}>
                        {connected ? '● connected' : '○ disconnected'}
                      </span>
                    </div>
                  )
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
      <TechStrip />
    </AppShell>
  )
}

function defaultScheduleTime() {
  const d = new Date()
  d.setHours(d.getHours() + 2, 0, 0, 0)
  return d.toISOString().slice(0, 16)
}
