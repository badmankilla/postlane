'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import toast from 'react-hot-toast'
import { Layers, Mail, Lock, ArrowRight } from 'lucide-react'
import api from '@/lib/api'
import { useAuthStore } from '@/hooks/useAuthStore'

const schema = z.object({
  email: z.string().email('Invalid email'),
  password: z.string().min(1, 'Required'),
})
type Form = z.infer<typeof schema>

export default function LoginPage() {
  const router = useRouter()
  const { setAuth } = useAuthStore()
  const [loading, setLoading] = useState(false)
  const [mode, setMode] = useState<'login' | 'register'>('login')

  const { register, handleSubmit, formState: { errors } } = useForm<Form>({ resolver: zodResolver(schema) })

  const onSubmit = async (data: Form) => {
    setLoading(true)
    try {
      if (mode === 'register') {
        await api.post('/api/auth/register', {
          email: data.email,
          username: data.email.split('@')[0],
          password: data.password,
        })
        toast.success('Account created! Logging in...')
      }
      const form = new URLSearchParams()
      form.set('username', data.email)
      form.set('password', data.password)
      const res = await api.post('/api/auth/login', form, {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      })
      const token = res.data.access_token
      const me = await api.get('/api/auth/me', { headers: { Authorization: `Bearer ${token}` } })
      setAuth(me.data, token)
      router.push('/dashboard')
    } catch (e: any) {
      toast.error(e.response?.data?.detail || 'Authentication failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: 'var(--bg)' }}>
      {/* Background grid */}
      <div className="absolute inset-0 opacity-[0.03]"
        style={{ backgroundImage: 'linear-gradient(var(--border2) 1px, transparent 1px), linear-gradient(90deg, var(--border2) 1px, transparent 1px)', backgroundSize: '40px 40px' }} />

      <div className="w-full max-w-sm relative">
        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
            style={{ background: 'var(--accent)', boxShadow: '0 0 40px rgba(108,92,231,0.4)' }}>
            <Layers size={24} color="white" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight">Postlane</h1>
          <p className="text-[13px] mt-1" style={{ color: 'var(--muted)' }}>Social scheduling for indie hackers</p>
        </div>

        {/* Card */}
        <div className="rounded-2xl p-6" style={{ background: 'var(--bg2)', border: '1px solid var(--border)' }}>
          <div className="flex gap-1 mb-6 p-1 rounded-lg" style={{ background: 'var(--bg3)' }}>
            {(['login', 'register'] as const).map(m => (
              <button key={m} onClick={() => setMode(m)}
                className="flex-1 py-2 text-[12px] font-semibold rounded-md capitalize transition-all"
                style={mode === m
                  ? { background: 'var(--bg2)', color: 'var(--text)', boxShadow: '0 1px 3px rgba(0,0,0,0.4)' }
                  : { color: 'var(--muted)', background: 'transparent' }}>
                {m}
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-4">
            <div>
              <label className="text-[11px] uppercase tracking-wider mb-1.5 flex items-center gap-1.5" style={{ color: 'var(--muted)' }}>
                <Mail size={11} /> Email
              </label>
              <input {...register('email')} type="email" placeholder="you@example.com"
                style={{ background: 'var(--bg3)', border: `1px solid ${errors.email ? 'var(--red)' : 'var(--border2)'}` }} />
              {errors.email && <p className="text-[11px] mt-1" style={{ color: 'var(--red)' }}>{errors.email.message}</p>}
            </div>

            <div>
              <label className="text-[11px] uppercase tracking-wider mb-1.5 flex items-center gap-1.5" style={{ color: 'var(--muted)' }}>
                <Lock size={11} /> Password
              </label>
              <input {...register('password')} type="password" placeholder="••••••••"
                style={{ background: 'var(--bg3)', border: `1px solid ${errors.password ? 'var(--red)' : 'var(--border2)'}` }} />
              {errors.password && <p className="text-[11px] mt-1" style={{ color: 'var(--red)' }}>{errors.password.message}</p>}
            </div>

            <button type="submit" disabled={loading}
              className="w-full py-2.5 rounded-lg font-semibold text-[13px] text-white flex items-center justify-center gap-2 transition-all mt-2"
              style={{ background: loading ? 'rgba(108,92,231,0.5)' : 'var(--accent)' }}>
              {loading ? 'Please wait...' : <>{mode === 'login' ? 'Sign in' : 'Create account'} <ArrowRight size={14} /></>}
            </button>
          </form>
        </div>

        <p className="text-center text-[11px] mt-4 font-mono-custom" style={{ color: 'var(--muted)' }}>
          Redis · BullMQ · FastAPI · PostgreSQL
        </p>
      </div>
    </div>
  )
}
