'use client'
import { useState } from 'react'
import Link from 'next/link'
import toast from 'react-hot-toast'
import { Plus, RefreshCw, Trash2, Clock, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react'
import AppShell from '@/components/layout/AppShell'
import { Card, TopBar, Button, PlatformPill, StatusBadge, TechStrip, EmptyState, Spinner } from '@/components/ui'
import { usePosts, useQueueStats, useDeletePost } from '@/hooks/useApi'
import { formatDateTime, formatNumber } from '@/lib/utils'
import type { PostStatus } from '@/types'

const STATUS_FILTERS: { label: string; value: PostStatus | 'all' }[] = [
  { label: 'All', value: 'all' },
  { label: 'Queued', value: 'queued' },
  { label: 'Processing', value: 'processing' },
  { label: 'Sent', value: 'sent' },
  { label: 'Failed', value: 'failed' },
]

export default function QueuePage() {
  const [filter, setFilter] = useState<PostStatus | 'all'>('all')
  const { data: posts, isLoading, refetch } = usePosts(filter === 'all' ? undefined : filter)
  const { data: stats } = useQueueStats()
  const deletePost = useDeletePost()

  const handleDelete = async (id: number) => {
    try {
      await deletePost.mutateAsync(id)
      toast.success('Post removed from queue')
    } catch {
      toast.error('Could not delete post')
    }
  }

  return (
    <AppShell>
      <TopBar title="Job queue" sub={`BullMQ · Redis · ${stats?.worker_count ?? 10} workers`}>
        <div className="flex items-center gap-2 text-[12px] font-mono-custom">
          <span className="w-2 h-2 rounded-full pulse-dot" style={{ background: 'var(--green)' }} />
          <span style={{ color: 'var(--green)' }}>All workers healthy</span>
        </div>
        <Button variant="ghost" size="sm" onClick={() => refetch()}>
          <RefreshCw size={12} /> Refresh
        </Button>
        <Link href="/compose"><Button size="sm"><Plus size={13} /> Schedule post</Button></Link>
      </TopBar>

      <div className="flex-1 overflow-y-auto p-7 flex flex-col gap-5">

        {/* Stats cards */}
        {stats && (
          <div className="grid grid-cols-4 gap-3">
            {[
              { label: 'Queued',     value: stats.queued,     icon: Clock,         color: 'var(--amber)' },
              { label: 'Processing', value: stats.processing, icon: Loader2,       color: 'var(--blue)'  },
              { label: 'Completed',  value: stats.completed,  icon: CheckCircle2,  color: 'var(--green)' },
              { label: 'Failed',     value: stats.failed,     icon: AlertCircle,   color: 'var(--red)'   },
            ].map(({ label, value, icon: Icon, color }) => (
              <Card key={label} className="p-4 flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{ background: color + '18' }}>
                  <Icon size={16} style={{ color }} />
                </div>
                <div>
                  <p className="text-[11px] uppercase tracking-wider" style={{ color: 'var(--muted)' }}>{label}</p>
                  <p className="text-2xl font-bold font-mono-custom leading-tight" style={{ color }}>{value}</p>
                </div>
              </Card>
            ))}
          </div>
        )}

        {/* Delivery rate banner */}
        {stats && (
          <div className="flex items-center gap-4 px-5 py-3 rounded-xl"
            style={{ background: 'rgba(0,214,143,0.06)', border: '1px solid rgba(0,214,143,0.15)' }}>
            <span className="w-2 h-2 rounded-full pulse-dot flex-shrink-0" style={{ background: 'var(--green)' }} />
            <p className="text-[12px]" style={{ color: 'var(--muted)' }}>
              On-time delivery: <span className="font-bold" style={{ color: 'var(--green)' }}>{stats.on_time_rate}%</span>
              {stats.next_delivery_in_seconds != null && (
                <> · Next post in <span className="font-bold" style={{ color: 'var(--text)' }}>{formatSeconds(stats.next_delivery_in_seconds)}</span></>
              )}
            </p>
            <div className="ml-auto flex items-center gap-2 text-[11px] font-mono-custom" style={{ color: 'var(--muted)' }}>
              <span style={{ color: 'var(--accent2)' }}>Redis ZSET</span> · exponential backoff · max {3} retries
            </div>
          </div>
        )}

        {/* Filter tabs */}
        <div className="flex gap-1 p-1 rounded-lg w-fit" style={{ background: 'var(--bg2)', border: '1px solid var(--border)' }}>
          {STATUS_FILTERS.map(({ label, value }) => (
            <button key={value} onClick={() => setFilter(value)}
              className="px-4 py-1.5 rounded-md text-[12px] font-semibold transition-all"
              style={filter === value
                ? { background: 'var(--accent)', color: 'white' }
                : { color: 'var(--muted)', background: 'transparent' }}>
              {label}
            </button>
          ))}
        </div>

        {/* Posts table */}
        <Card>
          {/* Header */}
          <div className="grid px-5 py-3 border-b text-[10px] uppercase tracking-[0.8px]"
            style={{ borderColor: 'var(--border)', color: 'var(--muted)', gridTemplateColumns: '2.5fr 1fr 1fr 1fr 80px 40px' }}>
            {['Content', 'Platform', 'Scheduled', 'Status', 'Impressions', ''].map(h => <span key={h}>{h}</span>)}
          </div>

          {isLoading ? <Spinner /> : !posts || posts.length === 0 ? (
            <EmptyState icon="📭" title="No posts" description="Schedule a post to see it here" />
          ) : (
            posts.map(post => (
              <div key={post.id} className="grid px-5 py-3 border-b items-center transition-colors hover:bg-white/[0.02] group"
                style={{ borderColor: 'var(--border)', gridTemplateColumns: '2.5fr 1fr 1fr 1fr 80px 40px' }}>
                <div className="min-w-0">
                  <p className="text-[12px] truncate max-w-[300px]">{post.content}</p>
                  <p className="text-[10px] font-mono-custom mt-0.5" style={{ color: 'var(--muted)' }}>
                    {post.content.length} chars · {post.job_id ?? 'no job id'}
                  </p>
                </div>
                <PlatformPill platform={post.platform} />
                <div>
                  <p className="text-[11px] font-mono-custom" style={{ color: 'var(--muted)' }}>{formatDateTime(post.scheduled_at)}</p>
                  {post.retry_count > 0 && (
                    <p className="text-[10px] font-mono-custom mt-0.5" style={{ color: 'var(--amber)' }}>retry #{post.retry_count}</p>
                  )}
                </div>
                <StatusBadge status={post.status} />
                <p className="text-[12px] font-mono-custom font-medium">
                  {post.analytics?.[0] ? formatNumber(post.analytics[0].impressions) : '—'}
                </p>
                <button
                  onClick={() => handleDelete(post.id)}
                  className="opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded"
                  style={{ color: 'var(--muted)' }}
                  title="Remove post">
                  <Trash2 size={13} />
                </button>
              </div>
            ))
          )}
        </Card>

        {/* Error details for failed posts */}
        {posts?.some(p => p.status === 'failed') && (
          <Card className="p-4">
            <p className="text-[12px] font-semibold mb-3" style={{ color: 'var(--red)' }}>Failed posts</p>
            {posts.filter(p => p.status === 'failed').map(post => (
              <div key={post.id} className="flex items-start gap-3 py-2">
                <AlertCircle size={14} style={{ color: 'var(--red)', flexShrink: 0, marginTop: 1 }} />
                <div>
                  <p className="text-[12px] truncate max-w-[400px]">{post.content}</p>
                  <p className="text-[11px] font-mono-custom mt-0.5" style={{ color: 'var(--red)' }}>
                    {post.error_message ?? 'Unknown error'} · {post.retry_count} attempts
                  </p>
                </div>
              </div>
            ))}
          </Card>
        )}
      </div>
      <TechStrip />
    </AppShell>
  )
}

function formatSeconds(s: number) {
  if (s < 60) return `${s}s`
  if (s < 3600) return `${Math.floor(s / 60)}m ${s % 60}s`
  return `${Math.floor(s / 3600)}h ${Math.floor((s % 3600) / 60)}m`
}
