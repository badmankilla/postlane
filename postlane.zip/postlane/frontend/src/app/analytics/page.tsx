'use client'
import { useState } from 'react'
import AppShell from '@/components/layout/AppShell'
import { Card, TopBar, TechStrip, Spinner, PlatformPill } from '@/components/ui'
import { useAnalyticsSummary, useDailyStats, useTopPosts } from '@/hooks/useApi'
import { formatNumber, formatDateTime, PLATFORM_META } from '@/lib/utils'
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend,
} from 'recharts'

const PERIODS = [7, 30, 90] as const
type Period = typeof PERIODS[number]

export default function AnalyticsPage() {
  const [period, setPeriod] = useState<Period>(30)
  const { data: summary, isLoading } = useAnalyticsSummary(period)
  const { data: daily } = useDailyStats(period)
  const { data: topPosts } = useTopPosts(10)

  const METRICS = [
    { label: 'Total Impressions',  value: formatNumber(summary?.total_impressions ?? 0),   color: 'var(--accent2)' },
    { label: 'Total Engagements',  value: formatNumber(summary?.total_engagements ?? 0),   color: 'var(--green)'   },
    { label: 'Eng. Rate',          value: `${summary?.avg_engagement_rate ?? 0}%`,          color: 'var(--amber)'   },
    { label: 'Posts Sent',         value: summary?.total_posts ?? 0,                        color: 'var(--blue)'    },
    { label: 'Link Clicks',        value: formatNumber(summary?.total_link_clicks ?? 0),    color: 'var(--pink)'    },
    { label: 'Follower Gain',      value: `+${summary?.follower_gain ?? 0}`,                color: 'var(--accent)'  },
  ]

  const PIE_DATA = [
    { name: 'Twitter/X', value: 58, color: '#1da1f2' },
    { name: 'LinkedIn',  value: 28, color: '#0077b5' },
    { name: 'Mastodon',  value: 14, color: '#6364ff' },
  ]

  return (
    <AppShell>
      <TopBar title="Analytics" sub="Impressions & engagement · all platforms">
        <div className="flex gap-1 p-1 rounded-lg" style={{ background: 'var(--bg2)', border: '1px solid var(--border)' }}>
          {PERIODS.map(p => (
            <button key={p} onClick={() => setPeriod(p)}
              className="px-3 py-1 rounded text-[12px] font-semibold transition-all"
              style={period === p
                ? { background: 'var(--accent)', color: 'white' }
                : { color: 'var(--muted)', background: 'transparent' }}>
              {p}d
            </button>
          ))}
        </div>
      </TopBar>

      <div className="flex-1 overflow-y-auto p-7 flex flex-col gap-5">
        {isLoading ? <Spinner /> : (
          <>
            {/* Summary metrics */}
            <div className="grid grid-cols-6 gap-3">
              {METRICS.map(({ label, value, color }) => (
                <div key={label} className="rounded-xl p-4"
                  style={{ background: 'var(--bg2)', border: `1px solid var(--border)`, borderTop: `2px solid ${color}` }}>
                  <p className="text-[10px] uppercase tracking-[0.8px] mb-2" style={{ color: 'var(--muted)' }}>{label}</p>
                  <p className="text-xl font-bold font-mono-custom" style={{ color }}>{value}</p>
                  <p className="text-[10px] mt-1 font-mono-custom" style={{ color: 'var(--green)' }}>↑ vs last period</p>
                </div>
              ))}
            </div>

            {/* Charts row */}
            <div className="grid grid-cols-3 gap-3">
              {/* Area chart */}
              <Card className="col-span-2 p-5">
                <p className="text-[13px] font-semibold mb-4">Impressions over time</p>
                <ResponsiveContainer width="100%" height={180}>
                  <AreaChart data={daily ?? MOCK_DAILY}>
                    <defs>
                      <linearGradient id="grad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#6c5ce7" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#6c5ce7" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid vertical={false} stroke="rgba(255,255,255,0.04)" />
                    <XAxis dataKey="date" tick={{ fill: 'var(--muted)', fontSize: 10, fontFamily: 'DM Mono' }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fill: 'var(--muted)', fontSize: 10, fontFamily: 'DM Mono' }} axisLine={false} tickLine={false} width={40} tickFormatter={v => formatNumber(v)} />
                    <Tooltip contentStyle={{ background: 'var(--bg3)', border: '1px solid var(--border2)', borderRadius: 8, fontSize: 12 }}
                      labelStyle={{ color: 'var(--text)' }} cursor={{ stroke: 'rgba(255,255,255,0.1)' }} />
                    <Area type="monotone" dataKey="impressions" stroke="#6c5ce7" strokeWidth={2} fill="url(#grad)" />
                  </AreaChart>
                </ResponsiveContainer>
              </Card>

              {/* Pie chart */}
              <Card className="p-5">
                <p className="text-[13px] font-semibold mb-2">Platform split</p>
                <ResponsiveContainer width="100%" height={180}>
                  <PieChart>
                    <Pie data={PIE_DATA} cx="50%" cy="50%" innerRadius={45} outerRadius={70}
                      paddingAngle={3} dataKey="value">
                      {PIE_DATA.map((entry) => <Cell key={entry.name} fill={entry.color} />)}
                    </Pie>
                    <Legend iconType="circle" iconSize={8}
                      formatter={(value) => <span style={{ color: 'var(--muted)', fontSize: 11 }}>{value}</span>} />
                    <Tooltip contentStyle={{ background: 'var(--bg3)', border: '1px solid var(--border2)', borderRadius: 8, fontSize: 12 }} />
                  </PieChart>
                </ResponsiveContainer>
              </Card>
            </div>

            {/* Engagement bar chart */}
            <Card className="p-5">
              <p className="text-[13px] font-semibold mb-4">Engagements by day</p>
              <ResponsiveContainer width="100%" height={130}>
                <BarChart data={daily ?? MOCK_DAILY} barSize={12}>
                  <CartesianGrid vertical={false} stroke="rgba(255,255,255,0.04)" />
                  <XAxis dataKey="date" tick={{ fill: 'var(--muted)', fontSize: 10, fontFamily: 'DM Mono' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: 'var(--muted)', fontSize: 10, fontFamily: 'DM Mono' }} axisLine={false} tickLine={false} width={30} />
                  <Tooltip contentStyle={{ background: 'var(--bg3)', border: '1px solid var(--border2)', borderRadius: 8, fontSize: 12 }}
                    cursor={{ fill: 'rgba(255,255,255,0.03)' }} />
                  <Bar dataKey="engagements" fill="#00d68f" radius={[3, 3, 0, 0]} opacity={0.85} />
                </BarChart>
              </ResponsiveContainer>
            </Card>

            {/* Top posts */}
            <Card>
              <div className="px-5 py-4 border-b" style={{ borderColor: 'var(--border)' }}>
                <p className="text-[13px] font-semibold">Top performing posts</p>
              </div>
              {/* Table header */}
              <div className="grid px-5 py-2.5 border-b text-[10px] uppercase tracking-[0.8px]"
                style={{ borderColor: 'var(--border)', color: 'var(--muted)', gridTemplateColumns: '2.5fr 1fr 80px 80px 70px' }}>
                {['Content', 'Platform', 'Views', 'Engagements', 'Rate'].map(h => (
                  <p key={h} className={h !== 'Content' && h !== 'Platform' ? 'text-right' : ''}>{h}</p>
                ))}
              </div>
              {(topPosts ?? MOCK_TOP_POSTS).map((post, i) => (
                <div key={post.id ?? i} className="grid px-5 py-3 border-b items-center hover:bg-white/[0.02] transition-colors"
                  style={{ borderColor: 'var(--border)', gridTemplateColumns: '2.5fr 1fr 80px 80px 70px' }}>
                  <p className="text-[12px] truncate max-w-[300px]">{post.content}</p>
                  <PlatformPill platform={post.platform} />
                  <p className="text-[12px] font-mono-custom font-medium text-right" style={{ color: 'var(--accent2)' }}>
                    {formatNumber(post.impressions)}
                  </p>
                  <p className="text-[12px] font-mono-custom font-medium text-right" style={{ color: 'var(--green)' }}>
                    {formatNumber(post.engagements)}
                  </p>
                  <p className="text-[12px] font-mono-custom font-medium text-right" style={{ color: 'var(--amber)' }}>
                    {post.engagement_rate.toFixed(1)}%
                  </p>
                </div>
              ))}
            </Card>
          </>
        )}
      </div>
      <TechStrip />
    </AppShell>
  )
}

const MOCK_DAILY = [
  { date: 'Mon', impressions: 5200, engagements: 412 },
  { date: 'Tue', impressions: 7800, engagements: 620 },
  { date: 'Wed', impressions: 4400, engagements: 310 },
  { date: 'Thu', impressions: 9100, engagements: 770 },
  { date: 'Fri', impressions: 6700, engagements: 490 },
  { date: 'Sat', impressions: 11000, engagements: 890 },
  { date: 'Sun', impressions: 8800, engagements: 710 },
]

const MOCK_TOP_POSTS = [
  { id: 1, content: 'Shipped v2.1 — dark mode finally live 🌙', platform: 'twitter' as const, impressions: 2841, engagements: 312, engagement_rate: 11.0, sent_at: null },
  { id: 2, content: '5 lessons from my first 100 paying customers (thread)', platform: 'linkedin' as const, impressions: 1990, engagements: 198, engagement_rate: 9.9, sent_at: null },
  { id: 3, content: 'The pricing page change that 3x\'d my conversion', platform: 'twitter' as const, impressions: 1654, engagements: 121, engagement_rate: 7.3, sent_at: null },
  { id: 4, content: 'Building in public: month 6 revenue update', platform: 'mastodon' as const, impressions: 1422, engagements: 88, engagement_rate: 6.2, sent_at: null },
  { id: 5, content: 'Why I chose FastAPI over Django for my side project', platform: 'linkedin' as const, impressions: 1187, engagements: 74, engagement_rate: 6.2, sent_at: null },
]
